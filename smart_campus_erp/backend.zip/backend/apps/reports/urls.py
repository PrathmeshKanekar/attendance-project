from django.urls import path
from .views import (
    AttendanceSummaryView,
    DefaultersView,
    DownloadPDFView,
    DownloadExcelView,
    StudentMyAttendanceView,
    TeacherSessionHistoryView,
    CollegeOverviewView,
    DashboardSummaryView,
    AttendanceTrendsView,
    HODSummaryView,
    PrincipalSummaryView,
)

urlpatterns = [
    path('attendance-summary/',       AttendanceSummaryView.as_view(),    name='report-summary'),
    path('defaulters/',               DefaultersView.as_view(),           name='report-defaulters'),
    path('download/pdf/',             DownloadPDFView.as_view(),          name='report-pdf'),
    path('download/excel/',           DownloadExcelView.as_view(),        name='report-excel'),
    path('attendance/pdf/',           DownloadPDFView.as_view(),          name='report-attendance-pdf'),
    path('attendance/excel/',         DownloadExcelView.as_view(),        name='report-attendance-excel'),
    path('student/my-attendance/',    StudentMyAttendanceView.as_view(),  name='student-report'),
    path('teacher/session-history/',  TeacherSessionHistoryView.as_view(),name='teacher-history'),
    path('college/overview/',         CollegeOverviewView.as_view(),      name='college-overview'),
    
    # New analytical endpoints
    path('summary/',                  DashboardSummaryView.as_view(),     name='report-dashboard-summary'),
    path('trends/',                   AttendanceTrendsView.as_view(),      name='report-trends'),
    path('hod-summary/',              HODSummaryView.as_view(),            name='hod-summary'),
    path('principal-summary/',        PrincipalSummaryView.as_view(),      name='principal-summary'),
]
