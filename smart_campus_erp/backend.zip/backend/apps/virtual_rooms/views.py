import logging
from django.utils import timezone
from django.db import transaction
from rest_framework import viewsets, permissions, status
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import VirtualRoom, RoomCorner, RoomPresence, RoomEntryLog
from .serializers import VirtualRoomSerializer, RoomPresenceSerializer
from .permissions import IsLabAssistantOrReadOnly
from .geo_utils import check_inside_room

logger = logging.getLogger(__name__)

# ─── Stale presence cleanup threshold (seconds) ───────────────────────────────
PRESENCE_STALE_SECONDS = 60  # Mark as exited if no heartbeat for 60s


def _cleanup_stale_presence():
    """Mark users as exited if no heartbeat received in PRESENCE_STALE_SECONDS."""
    cutoff = timezone.now() - timezone.timedelta(seconds=PRESENCE_STALE_SECONDS)
    stale = RoomPresence.objects.filter(is_inside=True, last_heartbeat__lt=cutoff)
    for p in stale:
        p.mark_exited()
        RoomEntryLog.objects.create(
            room=p.room, user=p.user, college=p.college,
            event=RoomEntryLog.EXIT,
            lat=p.last_lat, lng=p.last_lng, accuracy=p.last_accuracy,
            meta={'reason': 'stale_heartbeat_auto_exit'},
        )


# ─── VirtualRoom CRUD ─────────────────────────────────────────────────────────

class VirtualRoomViewSet(viewsets.ModelViewSet):
    """
    CRUD for VirtualRooms.
    Only Lab Assistants can create/update/delete.
    All authenticated users in the same college can read.
    """
    queryset = VirtualRoom.objects.all().prefetch_related('corners')
    serializer_class = VirtualRoomSerializer
    permission_classes = [IsLabAssistantOrReadOnly]
    search_fields = ['name', 'building', 'department']
    ordering_fields = ['name', 'created_at', 'floor_number', 'capacity']
    filterset_fields = ['building', 'department', 'floor_number', 'is_active']

    def get_queryset(self):
        queryset = super().get_queryset()
        user = self.request.user
        if user and user.is_authenticated and hasattr(user, 'college') and user.college:
            queryset = queryset.filter(college=user.college)
            if user.role == 'lab_assistant':
                from apps.accounts.rbac import get_lab_assistant_departments
                depts = get_lab_assistant_departments(user)
                dept_names_and_codes = []
                for d in depts:
                    dept_names_and_codes.append(d.name)
                    dept_names_and_codes.append(d.code)
                queryset = queryset.filter(department__in=dept_names_and_codes)
        return queryset

    @action(detail=True, methods=['get'], url_path='occupancy',
            permission_classes=[IsAuthenticated])
    def occupancy(self, request, pk=None):
        """
        GET /api/virtual-rooms/{id}/occupancy/
        Returns live occupancy count and user list for a room.
        """
        room = self.get_object()
        _cleanup_stale_presence()

        active_presence = RoomPresence.objects.filter(
            room=room, is_inside=True
        ).select_related('user').order_by('-last_heartbeat')

        users_inside = []
        for p in active_presence:
            users_inside.append({
                'user_id': str(p.user.id),
                'name': f"{p.user.first_name} {p.user.last_name}".strip(),
                'role': p.user.role,
                'last_heartbeat': p.last_heartbeat.isoformat(),
                'entered_at': p.entered_at.isoformat(),
                'last_accuracy': p.last_accuracy,
            })

        return Response({
            'room_id': str(room.id),
            'room_name': room.name,
            'total_inside': len(users_inside),
            'users': users_inside,
            'timestamp': timezone.now().isoformat(),
        })


# ─── Room Presence Heartbeat ──────────────────────────────────────────────────

class RoomPresenceHeartbeatView(APIView):
    """
    POST /api/virtual-rooms/{room_id}/presence/heartbeat/

    Called every 10–15s by the Flutter app while the user is on an attendance
    or session screen. The backend re-validates the polygon and updates the
    presence record, returning is_inside so the app can react.

    Body: { lat, lng, accuracy, device_id }
    Returns: { is_inside, distance_to_boundary, validation_mode, stale_exited_count }
    """
    permission_classes = [IsAuthenticated]

    def post(self, request, room_id):
        try:
            room = VirtualRoom.objects.prefetch_related('corners').get(
                id=room_id,
                college=request.user.college,
                is_active=True,
            )
        except VirtualRoom.DoesNotExist:
            return Response({'error': 'Room not found.'}, status=404)

        lat = request.data.get('lat')
        lng = request.data.get('lng')
        accuracy = float(request.data.get('accuracy', 15.0))
        device_id = request.data.get('device_id', '')

        if lat is None or lng is None:
            return Response({'error': 'lat and lng are required.'}, status=400)

        try:
            lat = float(lat)
            lng = float(lng)
        except (TypeError, ValueError):
            return Response({'error': 'lat/lng must be numbers.'}, status=400)

        # ── Server-side polygon check ──────────────────────────────────────
        geo = check_inside_room(
            student_lat=lat, student_lng=lng, student_alt=0.0,
            room=room, gps_accuracy=accuracy,
        )
        is_inside = geo['is_valid']

        # ── Update or create presence record ──────────────────────────────
        with transaction.atomic():
            presence = RoomPresence.objects.filter(
                room=room, user=request.user, is_inside=True
            ).first()

            if is_inside:
                if presence:
                    # Update existing record
                    presence.last_lat = lat
                    presence.last_lng = lng
                    presence.last_accuracy = accuracy
                    presence.device_id = device_id
                    presence.save(update_fields=[
                        'last_lat', 'last_lng', 'last_accuracy',
                        'device_id', 'last_heartbeat'
                    ])
                else:
                    # New entry — create record + log entry event
                    presence = RoomPresence.objects.create(
                        room=room, user=request.user,
                        college=request.user.college,
                        last_lat=lat, last_lng=lng,
                        last_accuracy=accuracy, device_id=device_id,
                        is_inside=True,
                    )
                    RoomEntryLog.objects.create(
                        room=room, user=request.user,
                        college=request.user.college,
                        event=RoomEntryLog.ENTRY,
                        lat=lat, lng=lng, accuracy=accuracy,
                        is_polygon_validated=geo['inside_2d'],
                        device_id=device_id,
                        meta={
                            'validation_mode': geo['validation_mode'],
                            'slack_used': geo['slack_used'],
                            'distance_to_centre': geo['distance_to_centre'],
                        },
                    )
            else:
                # User is outside — mark existing presence as exited
                if presence:
                    presence.mark_exited()
                    RoomEntryLog.objects.create(
                        room=room, user=request.user,
                        college=request.user.college,
                        event=RoomEntryLog.EXIT,
                        lat=lat, lng=lng, accuracy=accuracy,
                        is_polygon_validated=False,
                        device_id=device_id,
                        meta={
                            'reason': geo['reason'],
                            'distance_to_boundary': geo['distance_to_boundary'],
                        },
                    )

        # ── Stale cleanup (cheap — runs only on heartbeat calls) ───────────
        stale_cutoff = timezone.now() - timezone.timedelta(seconds=PRESENCE_STALE_SECONDS)
        stale_count = RoomPresence.objects.filter(
            room=room, is_inside=True, last_heartbeat__lt=stale_cutoff
        ).count()

        return Response({
            'is_inside': is_inside,
            'inside_2d': geo.get('inside_2d', False),
            'distance_to_boundary': geo.get('distance_to_boundary', 0.0),
            'distance_to_centre': geo.get('distance_to_centre', 0.0),
            'validation_mode': geo.get('validation_mode', 'denied'),
            'reason': geo.get('reason', ''),
            'slack_used': geo.get('slack_used', 0.0),
            'stale_users_cleaned': stale_count,
            'timestamp': timezone.now().isoformat(),
        })


# ─── Teacher Heartbeat for Session ───────────────────────────────────────────

class TeacherSessionHeartbeatView(APIView):
    """
    POST /api/attendance/sessions/{session_id}/teacher-heartbeat/

    Teacher pings every 15s while session is active.
    If teacher has left the room polygon:
      - session is paused (status='paused')
      - students are notified via session status
    If teacher is back inside:
      - session auto-resumes

    Body: { lat, lng, accuracy }
    Returns: { session_status, is_inside, action_taken }
    """
    permission_classes = [IsAuthenticated]

    def post(self, request, session_id):
        from apps.attendance.models import AttendanceSession

        try:
            session = AttendanceSession.objects.select_related(
                'virtual_room', 'teacher'
            ).get(
                id=session_id,
                teacher=request.user,
            )
        except AttendanceSession.DoesNotExist:
            return Response({'error': 'Session not found.'}, status=404)

        if session.status not in ('active', 'paused'):
            return Response({
                'session_status': session.status,
                'is_inside': False,
                'action_taken': 'none',
                'message': f'Session is already {session.status}.'
            })

        lat = request.data.get('lat')
        lng = request.data.get('lng')
        accuracy = float(request.data.get('accuracy', 15.0))

        if lat is None or lng is None:
            return Response({'error': 'lat and lng are required.'}, status=400)

        room = session.virtual_room
        if not room:
            # No polygon — cannot validate, keep session active
            return Response({
                'session_status': session.status,
                'is_inside': True,
                'action_taken': 'none',
                'message': 'No room polygon configured; assuming inside.',
            })

        geo = check_inside_room(
            student_lat=float(lat), student_lng=float(lng), student_alt=0.0,
            room=room, gps_accuracy=accuracy,
        )
        is_inside = geo['is_valid']

        action_taken = 'none'
        if not is_inside and session.status == 'active':
            session.status = 'paused'
            session.save(update_fields=['status'])
            action_taken = 'session_paused'
            logger.warning(
                'SESSION PAUSED: teacher %s left room %s | session %s | dist_boundary=%.1fm',
                request.user.email, room.name, session.session_code,
                geo.get('distance_to_boundary', 0),
            )
        elif is_inside and session.status == 'paused':
            session.status = 'active'
            session.save(update_fields=['status'])
            action_taken = 'session_resumed'
            logger.info(
                'SESSION RESUMED: teacher %s returned to room %s | session %s',
                request.user.email, room.name, session.session_code,
            )

        return Response({
            'session_status': session.status,
            'is_inside': is_inside,
            'action_taken': action_taken,
            'distance_to_boundary': geo.get('distance_to_boundary', 0.0),
            'validation_mode': geo.get('validation_mode', 'denied'),
            'timestamp': timezone.now().isoformat(),
        })
