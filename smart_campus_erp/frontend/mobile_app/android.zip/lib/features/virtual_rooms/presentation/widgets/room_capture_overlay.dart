// room_capture_overlay.dart — Production GPS-stabilized corner capture
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import '../../../../core/constants/app_colors.dart';
import '../../data/models/corner_data.dart';

class RoomCaptureOverlay extends StatefulWidget {
  final Function(List<CornerData>) onCaptureComplete;
  const RoomCaptureOverlay({super.key, required this.onCaptureComplete});

  @override
  State<RoomCaptureOverlay> createState() => _RoomCaptureOverlayState();
}

class _RoomCaptureOverlayState extends State<RoomCaptureOverlay> {
  final List<CornerData> _captured = [];
  bool _fetching = false;
  int _currentCorner = 1;

  // Live GPS display (updated every second while user waits)
  StreamSubscription<Position>? _liveGpsSub;
  double _liveAccuracy = 0.0;
  bool _gpsReady = true;

  @override
  void initState() {
    super.initState();
    _startLiveGps();
  }

  @override
  void dispose() {
    _liveGpsSub?.cancel();
    super.dispose();
  }

  void _startLiveGps() {
    _liveGpsSub = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.bestForNavigation,
        distanceFilter: 0,
      ),
    ).listen((pos) {
      if (!mounted) return;
      setState(() {
        _liveAccuracy = pos.accuracy;
        _gpsReady = true;
      });
    });
  }

  Future<Position?> _collectPosition() async {
  try {
    // Add explicit timeout — don't wait forever indoors
    return await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.best,  // NOT bestForNavigation (too strict indoors)
    ).timeout(const Duration(seconds: 8), onTimeout: () {
      // If timeout, use the last known position from the stream
      return Geolocator.getLastKnownPosition();  // returns null if none
    });
  } catch (_) {
    return Geolocator.getLastKnownPosition();
  }
}

  Future<void> _captureCurrentCorner() async {
    if (_fetching) return;

    setState(() => _fetching = true);

    try {
      // Permission check
      bool enabled = await Geolocator.isLocationServiceEnabled();
      if (!enabled) {
        _showSnack('Location services are disabled. Enable GPS and try again.', AppColors.danger);
        return;
      }
      LocationPermission perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
        _showSnack('Location permission denied.', AppColors.danger);
        return;
      }

      // Fast GPS capture
      _showSnack('Locking GPS…', Colors.blueAccent);

      final pos = await _collectPosition();

      if (pos == null) {
        _showSnack(
          'Failed to capture GPS. Move to an open area and try again.',
          AppColors.danger,
        );
        return;
      }

      // Fast Corner data construction (No accuracy or corner-to-corner distance validation)
      final corner = CornerData(
        lat: pos.latitude,
        lng: pos.longitude,
        alt: pos.altitude,
        accuracy: pos.accuracy,
        altitudeAccuracy: 3.0,
        heading: pos.heading,
      );

      setState(() {
        _captured.add(corner);
      });

      if (_captured.length < 4) {
        setState(() => _currentCorner = _captured.length + 1);
        _showSnack(
          'Corner ${_captured.length} captured instantly!',
          AppColors.success,
        );
      } else {
        // All 4 corners captured
        _showSnack('All 4 corners captured! Saving room…', AppColors.success);
        await Future.delayed(const Duration(milliseconds: 300));
        if (mounted) {
          widget.onCaptureComplete(_captured);
          Navigator.pop(context);
        }
      }
    } catch (e) {
      _showSnack('Capture failed: $e', AppColors.danger);
    } finally {
      if (mounted) setState(() => _fetching = false);
    }
  }

  void _showSnack(String msg, Color bg) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(msg),
          backgroundColor: bg,
          duration: const Duration(seconds: 3),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            Expanded(child: _buildBody()),
            _buildFooter(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(color: Colors.white.withOpacity(0.08))),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'ROOM CORNER CAPTURE',
                style: TextStyle(
                  color: AppColors.primaryLight,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                ),
              ),
              SizedBox(height: 2),
              Text(
                'Walk clockwise around the classroom',
                style: TextStyle(color: Colors.white38, fontSize: 10),
              ),
            ],
          ),
          IconButton(
            icon: const Icon(Icons.close_rounded, color: Colors.white54),
            onPressed: () => Navigator.pop(context),
          ),
        ],
      ),
    );
  }

  Widget _buildBody() {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Corner progress ring
          _buildCornerRing(),
          const SizedBox(height: 32),

          // GPS signal status
          _buildGpsStatus(),
          const SizedBox(height: 24),

          // Instructions
          _buildInstructions(),
          const SizedBox(height: 32),

          // Progress dots
          _buildProgressDots(),
          const SizedBox(height: 24),

          // Captured corners list
          if (_captured.isNotEmpty) _buildCapturedList(),
        ],
      ),
    );
  }

  Widget _buildCornerRing() {
    return Container(
      width: 150,
      height: 150,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: Colors.white.withOpacity(0.03),
        border: Border.all(
          color: _fetching
              ? Colors.blueAccent
              : (_gpsReady ? AppColors.primaryLight : Colors.orange),
          width: 2.5,
        ),
        boxShadow: [
          BoxShadow(
            color: (_gpsReady ? AppColors.primaryLight : Colors.orange).withOpacity(0.15),
            blurRadius: 24,
            spreadRadius: 4,
          ),
        ],
      ),
      child: Center(
        child: _fetching
            ? const Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(
                    width: 32,
                    height: 32,
                    child: CircularProgressIndicator(
                      color: Colors.blueAccent,
                      strokeWidth: 3,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'SAMPLING',
                    style: TextStyle(color: Colors.blueAccent, fontSize: 9, letterSpacing: 1.5),
                  ),
                ],
              )
            : Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    'CORNER',
                    style: TextStyle(color: Colors.white38, fontSize: 10, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '$_currentCorner / 4',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 36,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  Widget _buildGpsStatus() {
    final isGood = _liveAccuracy > 0 && _liveAccuracy <= 100;
    final isOk = _liveAccuracy > 100 && _liveAccuracy <= 300;

    final color = isGood
        ? const Color(0xFF10B981)
        : isOk
            ? Colors.orange
            : Colors.red;

    final label = _liveAccuracy == 0
        ? 'Acquiring GPS…'
        : isGood
            ? 'Good signal (${_liveAccuracy.toStringAsFixed(0)}m)'
            : isOk
                ? 'Fair signal (${_liveAccuracy.toStringAsFixed(0)}m) — usable'
                : 'Poor signal (${_liveAccuracy.toStringAsFixed(0)}m) — move near window';

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color,
              boxShadow: [BoxShadow(color: color.withOpacity(0.5), blurRadius: 4)],
            ),
          ),
          const SizedBox(width: 10),
          Icon(Icons.gps_fixed_rounded, color: color, size: 14),
          const SizedBox(width: 6),
          Text(
            label,
            style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  Widget _buildInstructions() {
    final steps = [
      'Stand at Corner 1 (any corner) — tap Capture',
      'Walk clockwise to Corner 2 — tap Capture',
      'Continue to Corner 3 — tap Capture',
      'Walk to the final Corner 4 — tap Capture',
    ];

    final currentText = _captured.length < 4 ? steps[_captured.length] : 'All corners captured!';

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.04),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.06)),
      ),
      child: Row(
        children: [
          Icon(
            _captured.length < 4 ? Icons.directions_walk_rounded : Icons.check_circle_rounded,
            color: _captured.length < 4 ? AppColors.primaryLight : Colors.green,
            size: 20,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              currentText,
              style: const TextStyle(color: Colors.white70, fontSize: 12, height: 1.4),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProgressDots() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(4, (i) {
        final done = i < _captured.length;
        final active = i == _captured.length && i < 4;
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 8),
          width: done ? 28 : (active ? 16 : 12),
          height: 12,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(6),
            color: done
                ? const Color(0xFF10B981)
                : active
                    ? AppColors.primaryLight
                    : Colors.white12,
            border: Border.all(
              color: active ? Colors.white54 : Colors.transparent,
            ),
          ),
          child: done
              ? const Icon(Icons.check, color: Colors.white, size: 9)
              : null,
        );
      }),
    );
  }

  Widget _buildCapturedList() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'CAPTURED CORNERS',
          style: TextStyle(color: Colors.white38, fontSize: 9, letterSpacing: 1.5),
        ),
        const SizedBox(height: 8),
        ..._captured.asMap().entries.map((e) {
          final i = e.key;
          final c = e.value;
          return Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Row(
              children: [
                Container(
                  width: 22,
                  height: 22,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFF10B981).withOpacity(0.2),
                    border: Border.all(color: const Color(0xFF10B981), width: 1),
                  ),
                  child: Center(
                    child: Text(
                      '${i + 1}',
                      style: const TextStyle(
                        color: Color(0xFF10B981),
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Text(
                  '${c.lat.toStringAsFixed(6)}, ${c.lng.toStringAsFixed(6)}',
                  style: const TextStyle(color: Colors.white54, fontSize: 10),
                ),
                const Spacer(),
                Text(
                  '±${c.accuracy.toStringAsFixed(0)}m',
                  style: TextStyle(
                    color: c.accuracy <= 100 ? Colors.green : Colors.orange,
                    fontSize: 10,
                  ),
                ),
              ],
            ),
          );
        }),
      ],
    );
  }

  Widget _buildFooter() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 0, 24, 32),
      child: Column(
        children: [
          if (_captured.isNotEmpty) ...[
            TextButton.icon(
              icon: const Icon(Icons.undo_rounded, color: Colors.white54, size: 14),
              label: Text(
                'UNDO CORNER ${_captured.length}',
                style: const TextStyle(color: Colors.white54, fontSize: 10, fontWeight: FontWeight.bold),
              ),
              onPressed: _fetching
                  ? null
                  : () {
                      setState(() {
                        _captured.removeLast();
                        _currentCorner = _captured.length + 1;
                      });
                    },
            ),
            const SizedBox(height: 12),
          ],
          ElevatedButton.icon(
            onPressed: (_fetching || !_gpsReady) ? null : _captureCurrentCorner,
            icon: _fetching
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2),
                  )
                : const Icon(Icons.gps_fixed_rounded, color: Colors.black),
            label: Text(
              _fetching
                  ? 'SAMPLING GPS…'
                  : !_gpsReady
                      ? 'WAITING FOR GPS SIGNAL…'
                      : _captured.length < 4
                          ? 'CAPTURE CORNER $_currentCorner'
                          : 'ALL CORNERS CAPTURED',
              style: const TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: _fetching || !_gpsReady
                  ? Colors.grey.shade700
                  : AppColors.primaryLight,
              minimumSize: const Size(double.infinity, 56),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              disabledBackgroundColor: Colors.grey.shade800,
            ),
          ),
        ],
      ),
    );
  }
}
