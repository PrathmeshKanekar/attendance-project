class AppConstants {
  AppConstants._();

  // For Android emulator: 'http://10.0.2.2:8000'
  // For real device on same WiFi: 'http://192.168.X.X:8000'
  // For production: 'https://your-domain.com'
  static const String baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://10.72.249.98:8000',
  );

  static const String tokenKey   = 'access_token';
  static const String refreshKey = 'refresh_token';
  static const String userKey    = 'user_data';

  static const int connectTimeoutMs = 15000;
  static const int receiveTimeoutMs = 15000;

  static const int    requiredBlinks        = 3;
  static const double faceMatchConfidence   = 60.0;
  static const double defaultGeoRadiusMeters = 30.0;
}
