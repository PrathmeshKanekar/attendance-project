import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../constants/app_constants.dart';

final secureStorageProvider = Provider<FlutterSecureStorage>((ref) {
  return const FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
    wOptions: WindowsOptions(),
    lOptions: LinuxOptions(),
  );
});

final apiClientProvider = Provider<ApiClient>((ref) {
  final storage = ref.read(secureStorageProvider);
  return ApiClient(storage);
});

class ApiClient {
  late final Dio _dio;
  final FlutterSecureStorage _storage;

  ApiClient(this._storage) {
    _dio = Dio(
      BaseOptions(
        baseUrl        : AppConstants.baseUrl,
        connectTimeout : const Duration(
          milliseconds: AppConstants.connectTimeoutMs,
        ),
        receiveTimeout : const Duration(
          milliseconds: AppConstants.receiveTimeoutMs,
        ),
        headers        : {
          'Content-Type': 'application/json',
          'Accept'      : 'application/json',
        },
      ),
    );

    // Auth interceptor
    _dio.interceptors.add(_AuthInterceptor(_storage, _dio));
  }

  Dio get dio => _dio;

  Future<Response> download(
    String url,
    String savePath, {
    ProgressCallback? onReceiveProgress,
    Map<String, dynamic>? params,
  }) =>
      _dio.download(
        url,
        savePath,
        onReceiveProgress: onReceiveProgress,
        queryParameters  : params,
      );


  Future<Response> get(
    String path, {
    Map<String, dynamic>? params,
  }) =>
      _dio.get(path, queryParameters: params);

  Future<Response> post(String path, {dynamic data}) =>
      _dio.post(path, data: data);

  Future<Response> put(String path, {dynamic data}) =>
      _dio.put(path, data: data);

  Future<Response> patch(String path, {dynamic data}) =>
      _dio.patch(path, data: data);

  Future<Response> delete(String path) =>
      _dio.delete(path);

  // Download file as bytes
  Future<List<int>> downloadFile(
    String path, {
    Map<String, dynamic>? params,
  }) async {
    final res = await _dio.get<List<int>>(
      path,
      queryParameters   : params,
      options           : Options(responseType: ResponseType.bytes),
    );
    return res.data ?? [];
  }
}

class _AuthInterceptor extends Interceptor {
  final FlutterSecureStorage _storage;
  final Dio                  _dio;

  _AuthInterceptor(this._storage, this._dio);

  @override
  void onRequest(
    RequestOptions          options,
    RequestInterceptorHandler handler,
  ) async {
    // CRITICAL FIX: always read fresh token from storage
    final token = await _storage.read(key: AppConstants.tokenKey);
    if (token != null && token.isNotEmpty) {
      options.headers['Authorization'] = 'Bearer $token';
    }
    handler.next(options);
  }

  @override
  void onError(
    DioException             err,
    ErrorInterceptorHandler  handler,
  ) async {
    if (err.response?.statusCode == 401) {
      // Try token refresh
      try {
        final refresh = await _storage.read(
          key: AppConstants.refreshKey,
        );
        if (refresh == null || refresh.isEmpty) {
          // No refresh token — clear and propagate
          await _storage.deleteAll();
          handler.next(err);
          return;
        }

        // Call refresh endpoint with separate Dio instance
        final refreshDio = Dio(BaseOptions(
          baseUrl: AppConstants.baseUrl,
          headers: {'Content-Type': 'application/json'},
        ));

        final res = await refreshDio.post(
          '/api/auth/refresh/',
          data: {'refresh': refresh},
        );

        final newToken = res.data['access'] as String?;
        if (newToken == null || newToken.isEmpty) {
          await _storage.deleteAll();
          handler.next(err);
          return;
        }

        // Save new token
        await _storage.write(
          key: AppConstants.tokenKey, value: newToken,
        );

        // Also save new refresh if rotated
        final newRefresh = res.data['refresh'] as String?;
        if (newRefresh != null) {
          await _storage.write(
            key: AppConstants.refreshKey, value: newRefresh,
          );
        }

        // Retry original request with new token
        err.requestOptions.headers['Authorization'] =
            'Bearer $newToken';
        final retried = await _dio.fetch(err.requestOptions);
        handler.resolve(retried);
        return;

      } catch (_) {
        // Refresh failed — clear storage
        await _storage.deleteAll();
      }
    }
    handler.next(err);
  }
}
