import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../constants/app_constants.dart';
import '../models/user_model.dart';

class SecureStorageService {
  static const _storage = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  static final Map<String, String> _inMemoryCache = {};

  static FlutterSecureStorage get storage => _storage;

  static Future<void> saveTokens({
    required String access,
    required String refresh,
  }) async {
    _inMemoryCache[AppConstants.tokenKey] = access;
    _inMemoryCache[AppConstants.refreshKey] = refresh;
    try {
      await Future.wait([
        _storage.write(key: AppConstants.tokenKey, value: access),
        _storage.write(key: AppConstants.refreshKey, value: refresh),
      ]);
    } catch (_) {}
  }

  static Future<void> saveUser(UserModel user) async {
    final raw = jsonEncode(user.toJson());
    _inMemoryCache[AppConstants.userKey] = raw;
    try {
      await _storage.write(
        key: AppConstants.userKey,
        value: raw,
      );
    } catch (_) {}
  }

  static Future<UserModel?> loadUser() async {
    try {
      final raw = await _storage.read(key: AppConstants.userKey) ?? _inMemoryCache[AppConstants.userKey];
      if (raw == null) return null;
      return UserModel.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      final raw = _inMemoryCache[AppConstants.userKey];
      if (raw == null) return null;
      return UserModel.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    }
  }

  static Future<String?> getAccessToken() async {
    try {
      return await _storage.read(key: AppConstants.tokenKey) ?? _inMemoryCache[AppConstants.tokenKey];
    } catch (_) {
      return _inMemoryCache[AppConstants.tokenKey];
    }
  }

  static Future<void> clearAll() async {
    _inMemoryCache.clear();
    try {
      await _storage.deleteAll();
    } catch (_) {}
  }
}
