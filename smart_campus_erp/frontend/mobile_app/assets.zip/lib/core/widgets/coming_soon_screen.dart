import 'package:flutter/material.dart';
import '../layout/app_layout.dart';
import '../constants/app_colors.dart';

class ComingSoonScreen extends StatelessWidget {
  final String title;
  const ComingSoonScreen({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return AppLayout(
      title: title,
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.construction_rounded,
              size : 64,
              color: AppColors.warning,
            ),
            const SizedBox(height: 16),
            Text(
              title,
              style: const TextStyle(
                fontSize  : 22,
                fontWeight: FontWeight.bold,
                color     : AppColors.textPrimary,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'This module is coming in a future step.',
              style: TextStyle(
                color  : AppColors.textSecondary,
                fontSize: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
