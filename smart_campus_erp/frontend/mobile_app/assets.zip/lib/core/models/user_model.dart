class UserModel {
  final String  id;
  final String  email;
  final String  firstName;
  final String  lastName;
  final String  fullName;
  final String  role;
  final String? phone;
  final String? profilePhoto;
  final String? collegeId;
  final String? collegeName;
  final String? collegeCode;
  final String? prn;
  final String? deviceId;
  final bool    isApproved;
  final bool    isActive;

  const UserModel({
    required this.id,
    required this.email,
    required this.firstName,
    required this.lastName,
    required this.fullName,
    required this.role,
    this.phone,
    this.profilePhoto,
    this.collegeId,
    this.collegeName,
    this.collegeCode,
    this.prn,
    this.deviceId,
    required this.isApproved,
    required this.isActive,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id           : json['id']           as String,
      email        : json['email']        as String,
      firstName    : json['first_name']   as String,
      lastName     : json['last_name']    as String,
      fullName     : json['full_name']    as String,
      role         : json['role']         as String,
      phone        : json['phone']        as String?,
      profilePhoto : json['profile_photo'] as String?,
      collegeId    : json['college_id']   as String?,
      collegeName  : json['college_name'] as String?,
      collegeCode  : json['college_code'] as String?,
      prn          : json['prn']          as String?,
      deviceId     : json['device_id']    as String?,
      isApproved   : json['is_approved']  as bool? ?? false,
      isActive     : json['is_active']    as bool? ?? false,
    );
  }

  Map<String, dynamic> toJson() => {
    'id'           : id,
    'email'        : email,
    'first_name'   : firstName,
    'last_name'    : lastName,
    'full_name'    : fullName,
    'role'         : role,
    'phone'        : phone,
    'profile_photo': profilePhoto,
    'college_id'   : collegeId,
    'college_name' : collegeName,
    'college_code' : collegeCode,
    'prn'          : prn,
    'device_id'    : deviceId,
    'is_approved'  : isApproved,
    'is_active'    : isActive,
  };

  bool get isStudent      => role == 'student';
  bool get isTeacher      => role == 'teacher';
  bool get isPrincipal    => role == 'principal';
  bool get isHOD          => role == 'hod';
  bool get isCollegeAdmin => role == 'college_admin';
  bool get isSuperAdmin   => role == 'super_admin';
  bool get isLabAssistant => role == 'lab_assistant';

  String get initials {
    final f = firstName.isNotEmpty ? firstName[0] : '';
    final l = lastName.isNotEmpty  ? lastName[0]  : '';
    return '$f$l'.toUpperCase();
  }
}
