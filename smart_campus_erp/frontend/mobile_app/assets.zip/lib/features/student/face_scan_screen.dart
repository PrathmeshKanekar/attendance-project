import 'dart:convert';
import 'dart:typed_data';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../core/constants/app_colors.dart';
import '../../core/network/api_client.dart';
import '../../core/services/device_service.dart';
import 'providers/student_providers.dart';

class FaceScanScreen extends ConsumerStatefulWidget {
  final Map<String, dynamic> session;
  final double               lat;
  final double               lng;
  final double               altitude;

  const FaceScanScreen({
    super.key,
    required this.session,
    required this.lat,
    required this.lng,
    required this.altitude,
  });

  @override
  ConsumerState<FaceScanScreen> createState() => _FaceScanScreenState();
}

class _FaceScanScreenState extends ConsumerState<FaceScanScreen> {
  CameraController? _controller;
  XFile?            _capturedImage;
  Uint8List?        _capturedImageBytes;
  bool              _isInitializing = true;
  bool              _isSubmitting   = false;
  String?           _initError;

  final _deviceService   = DeviceService();

  @override
  void initState() {
    super.initState();
    // CRITICAL FIX: Guard against empty session
    if (widget.session.isEmpty) {
      _initError = 'Session data not found.';
      _isInitializing = false;
      return;
    }
    WidgetsBinding.instance.addPostFrameCallback((_) => _initCamera());
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  Future<void> _initCamera() async {
    final status = await Permission.camera.request();
    if (!status.isGranted) {
      setState(() {
        _isInitializing = false;
        _initError = 'Camera permission denied. Please allow camera access in settings.';
      });
      return;
    }

    try {
      final cameras = await availableCameras();
      if (cameras.isEmpty) {
        setState(() {
          _isInitializing = false;
          _initError = 'No cameras found on this device.';
        });
        return;
      }

      final frontCamera = cameras.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.front,
        orElse: () => cameras.first,
      );

      _controller = CameraController(
        frontCamera,
        ResolutionPreset.high,
        enableAudio: false,
        imageFormatGroup: ImageFormatGroup.jpeg,
      );

      await _controller!.initialize();
      if (mounted) {
        setState(() => _isInitializing = false);
      }
    } catch (e) {
      setState(() {
        _isInitializing = false;
        _initError = 'Failed to initialize camera: $e';
      });
    }
  }

  Future<void> _capturePhoto() async {
    if (_controller == null || !_controller!.value.isInitialized) return;
    try {
      final xfile = await _controller!.takePicture();
      final bytes = await xfile.readAsBytes();
      setState(() {
        _capturedImage = xfile;
        _capturedImageBytes = bytes;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content        : Text('Capture failed: $e'),
            backgroundColor: AppColors.danger,
          ),
        );
      }
    }
  }

  Future<void> _submitAttendance() async {
    if (_capturedImageBytes == null) return;

    setState(() {
      _isSubmitting = true;
    });

    try {
      final b64 = base64Encode(_capturedImageBytes!);
      final devId = await _deviceService.getDeviceId();
      final api = ref.read(apiClientProvider);

      final res = await api.post('/api/attendance/mark/', data: {
        'session_id'    : widget.session['id'],
        'lat'           : widget.lat,
        'lng'           : widget.lng,
        'altitude'      : widget.altitude,
        'device_id'     : devId,
        'face_image_b64': b64,
        'blink_count'   : 3,
      });

      if (mounted) {
        ref.invalidate(studentActiveSessionsProvider);
        ref.invalidate(studentAttendanceSummaryProvider);

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content        : Text(res.data['message'] ?? 'Attendance marked successfully.'),
            backgroundColor: AppColors.success,
          ),
        );
        context.go('/student/dashboard');
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content        : Text(e.toString().contains('"error"') ? 'Geofence / Verification Failed' : e.toString()),
            backgroundColor: AppColors.danger,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isSubmitting = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        iconTheme: const IconThemeData(color: Colors.white),
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Mark Attendance — Face Scan',
              style: TextStyle(color: Colors.white, fontSize: 17),
            ),
            Text(
              'Step 2: Liveness & Verification',
              style: TextStyle(color: Colors.white70, fontSize: 13),
            ),
          ],
        ),
      ),
      body: Stack(
        children: [
          if (_isInitializing)
            const Center(child: CircularProgressIndicator(color: Colors.white))
          else if (_initError != null)
            Center(
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.camera_alt_outlined,
                      color: Colors.white54,
                      size: 64,
                    ),
                    const SizedBox(height: 16),
                    Text(
                      _initError!,
                      style: const TextStyle(color: Colors.white70),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            )
          else if (_capturedImage == null)
            SizedBox.expand(child: CameraPreview(_controller!))
          else
            SizedBox.expand(
              child: Image.memory(
                _capturedImageBytes!,
                fit: BoxFit.cover,
              ),
            ),

          if (_capturedImage == null && !_isInitializing && _initError == null)
            Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 220,
                    height: 280,
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: Colors.white.withOpacity(0.70),
                        width: 2,
                      ),
                      borderRadius: BorderRadius.circular(120),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.black54,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Text(
                      'Blink exactly 3 times\nPosition face inside the oval',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                      ),
                    ),
                  ),
                ],
              ),
            ),

          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: EdgeInsets.fromLTRB(
                24, 20, 24,
                MediaQuery.of(context).padding.bottom + 20,
              ),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [Colors.black87, Colors.transparent],
                ),
              ),
              child: _capturedImage == null
                  ? _buildCaptureButton()
                  : _buildConfirmButtons(),
            ),
          ),

          if (_isSubmitting)
            Container(
              color: Colors.black54,
              child: const Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircularProgressIndicator(color: Colors.white),
                    SizedBox(height: 16),
                    Text(
                      'Marking attendance...\nThis may take a few seconds.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white, fontSize: 15),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildCaptureButton() {
    return Center(
      child: GestureDetector(
        onTap: _capturePhoto,
        child: Container(
          width: 72,
          height: 72,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.white,
            border: Border.all(color: Colors.white30, width: 4),
          ),
          child: const Icon(
            Icons.camera_alt_rounded,
            size: 36,
            color: AppColors.primary,
          ),
        ),
      ),
    );
  }

  Widget _buildConfirmButtons() {
    return Row(
      children: [
        Expanded(
          child: OutlinedButton.icon(
            style: OutlinedButton.styleFrom(
              foregroundColor: Colors.white,
              side: const BorderSide(color: Colors.white54),
              minimumSize: const Size(0, 52),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            onPressed: () => setState(() {
              _capturedImage = null;
              _capturedImageBytes = null;
            }),
            icon: const Icon(Icons.refresh_rounded),
            label: const Text('Retake'),
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          flex: 2,
          child: ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.success,
              minimumSize: const Size(0, 52),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            onPressed: _submitAttendance,
            icon: const Icon(Icons.check_circle_rounded),
            label: const Text('Submit & Mark'),
          ),
        ),
      ],
    );
  }
}
