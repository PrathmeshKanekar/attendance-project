import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/network/api_client.dart';

// ── Student my attendance ──────────────────────────────────
final studentMyAttendanceProvider =
    FutureProvider<List<Map<String, dynamic>>>((ref) async {
  final api = ref.read(apiClientProvider);
  final res = await api.get('/api/reports/student/my-attendance/');
  return List<Map<String, dynamic>>.from(res.data as List);
});

// ── College overview (principal/HOD) ──────────────────────
final collegeOverviewProvider =
    FutureProvider<Map<String, dynamic>>((ref) async {
  final api = ref.read(apiClientProvider);
  final res = await api.get('/api/reports/college/overview/');
  return Map<String, dynamic>.from(res.data as Map);
});

// ── Teacher session history ────────────────────────────────
final teacherSessionHistoryProvider =
    FutureProvider.family<List<Map<String, dynamic>>, String?>(
  (ref, allocationId) async {
    final api    = ref.read(apiClientProvider);
    final params = <String, dynamic>{'limit': '20'};
    if (allocationId != null) params['allocation_id'] = allocationId;
    final res = await api.get('/api/reports/teacher/session-history/',
        params: params);
    return List<Map<String, dynamic>>.from(res.data as List);
  },
);

// ── Attendance summary (teacher filter) ───────────────────
final attendanceSummaryProvider =
    FutureProvider.family<Map<String, dynamic>, Map<String, String>>(
  (ref, params) async {
    final api = ref.read(apiClientProvider);
    final res = await api.get('/api/reports/attendance-summary/',
        params: params);
    return Map<String, dynamic>.from(res.data as Map);
  },
);

// ── Defaulters ────────────────────────────────────────────
final defaultersProvider =
    FutureProvider.family<Map<String, dynamic>, Map<String, String>>(
  (ref, params) async {
    final api = ref.read(apiClientProvider);
    final res = await api.get('/api/reports/defaulters/', params: params);
    return Map<String, dynamic>.from(res.data as Map);
  },
);
