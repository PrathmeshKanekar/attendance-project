import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../core/constants/app_colors.dart';
import '../../core/layout/app_layout.dart';
import '../../core/network/api_client.dart';
import '../../core/widgets/empty_state_widget.dart';
import '../../core/widgets/error_widget.dart';
import '../../core/widgets/loading_widget.dart';
import '../../core/providers/auth_provider.dart';


// ── Providers ──────────────────────────────────────────────

final mySessionsProvider =
    FutureProvider<Map<String, dynamic>>((ref) async {
  final api = ref.read(apiClientProvider);
  final res = await api.get('/api/attendance/sessions/my/');
  return Map<String, dynamic>.from(res.data as Map);
});

final teacherRoomsProvider =
    FutureProvider<List<Map<String, dynamic>>>((ref) async {
  // CRITICAL FIX: wait until auth is ready
  final authState = ref.watch(authProvider);
  if (authState is! AuthSuccess) return [];

  final api = ref.read(apiClientProvider);
  final res = await api.get('/api/virtual-rooms/');

  // CRITICAL FIX: handle both list and wrapped response
  if (res.data is List) {
    return List<Map<String, dynamic>>.from(
      (res.data as List).map((e) => Map<String, dynamic>.from(e as Map)),
    );
  }
  if (res.data is Map && res.data['results'] != null) {
    return List<Map<String, dynamic>>.from(res.data['results'] as List);
  }
  return [];
});

final teacherAllocationsProvider =
    FutureProvider<List<Map<String, dynamic>>>((ref) async {
  final authState = ref.watch(authProvider);
  if (authState is! AuthSuccess) return [];

  final api = ref.read(apiClientProvider);
  final res = await api.get('/api/allocations/my/');

  if (res.data is List) {
    return List<Map<String, dynamic>>.from(
      (res.data as List).map((e) => Map<String, dynamic>.from(e as Map)),
    );
  }
  return [];
});


// ── Session state ──────────────────────────────────────────

abstract class SessionActionState {}
class SessionActionIdle    extends SessionActionState {}
class SessionActionLoading extends SessionActionState {}
class SessionActionSuccess extends SessionActionState {
  final String message;
  SessionActionSuccess(this.message);
}
class SessionActionError   extends SessionActionState {
  final String message;
  SessionActionError(this.message);
}

class SessionActionNotifier extends StateNotifier<SessionActionState> {
  final ApiClient _api;
  final Ref       _ref;

  SessionActionNotifier(this._api, this._ref)
      : super(SessionActionIdle());

  Future<bool> startSession(Map<String, dynamic> body) async {
    state = SessionActionLoading();
    try {
      final res = await _api.post('/api/attendance/sessions/', data: body);
      _ref.invalidate(mySessionsProvider);
      state = SessionActionSuccess(
        res.data['message']?.toString() ?? 'Session started.',
      );
      return true;
    } on Exception catch (e) {
      state = SessionActionError(_extract(e));
      return false;
    }
  }

  Future<bool> endSession(String sessionId) async {
    state = SessionActionLoading();
    try {
      final res = await _api.post(
        '/api/attendance/sessions/$sessionId/end/',
      );
      _ref.invalidate(mySessionsProvider);
      state = SessionActionSuccess(
        res.data['message']?.toString() ?? 'Session ended.',
      );
      return true;
    } on Exception catch (e) {
      state = SessionActionError(_extract(e));
      return false;
    }
  }

  void reset() => state = SessionActionIdle();

  String _extract(Exception e) {
    final msg = e.toString();
    if (msg.contains('"error"')) {
      try {
        final start = msg.indexOf('"error":') + 9;
        final sub   = msg.substring(start);
        final end   = sub.indexOf('"', 1);
        return sub.substring(1, end);
      } catch (_) {}
    }
    return msg.replaceAll('Exception: ', '');
  }
}

final sessionActionProvider =
    StateNotifierProvider<SessionActionNotifier, SessionActionState>((ref) {
  return SessionActionNotifier(ref.read(apiClientProvider), ref);
});


// ══════════════════════════════════════════════════════════
// MAIN SCREEN
// ══════════════════════════════════════════════════════════

class TeacherSessionsScreen extends ConsumerStatefulWidget {
  const TeacherSessionsScreen({super.key});

  @override
  ConsumerState<TeacherSessionsScreen> createState() =>
      _TeacherSessionsScreenState();
}

class _TeacherSessionsScreenState
    extends ConsumerState<TeacherSessionsScreen>
    with SingleTickerProviderStateMixin {

  late TabController _tabCtrl;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final async = ref.watch(mySessionsProvider);

    return AppLayout(
      title  : 'My Sessions',
      actions: [
        IconButton(
          icon     : const Icon(Icons.refresh_rounded),
          onPressed: () => ref.invalidate(mySessionsProvider),
          tooltip  : 'Refresh',
        ),
      ],
      fab: FloatingActionButton.extended(
        onPressed      : () => _showStartSessionSheet(context, ref),
        icon           : const Icon(Icons.play_arrow_rounded),
        label          : const Text('Start Session'),
        backgroundColor: AppColors.success,
      ),
      child: async.when(
        loading: () => const LoadingWidget(message: 'Loading sessions...'),
        error  : (e, _) => AppErrorWidget(
          message: e.toString(),
          onRetry: () => ref.invalidate(mySessionsProvider),
        ),
        data   : (data) {
          final sessions     = List<Map<String, dynamic>>.from(
            data['sessions'] as List,
          );
          final activeCount  = data['active_count'] as int? ?? 0;

          final activeSessions = sessions
              .where((s) => s['status'] == 'active')
              .toList();
          final pastSessions = sessions
              .where((s) => s['status'] != 'active')
              .toList();

          return Column(
            children: [

              // ── Active session banner ──────────────────
              if (activeCount > 0)
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20, vertical: 10,
                  ),
                  color: AppColors.success.withOpacity(0.08),
                  child: Row(
                    children: [
                      _PulsingDot(),
                      const SizedBox(width: 8),
                      Text(
                        '$activeCount active session${activeCount > 1 ? 's' : ''} running',
                        style: const TextStyle(
                          color     : AppColors.success,
                          fontWeight: FontWeight.w600,
                          fontSize  : 14,
                        ),
                      ),
                    ],
                  ),
                ),

              // ── Tab bar ────────────────────────────────
              Container(
                color: AppColors.cardBg,
                child: TabBar(
                  controller  : _tabCtrl,
                  labelColor  : AppColors.primaryLight,
                  unselectedLabelColor: AppColors.textSecondary,
                  indicatorColor: AppColors.primaryLight,
                  tabs: [
                    Tab(text: 'Active (${activeSessions.length})'),
                    Tab(text: 'Past (${pastSessions.length})'),
                  ],
                ),
              ),

              // ── Tab views ──────────────────────────────
              Expanded(
                child: TabBarView(
                  controller: _tabCtrl,
                  children  : [

                    // Active sessions tab
                    activeSessions.isEmpty
                        ? const EmptyStateWidget(
                            message : 'No active sessions',
                            icon    : Icons.event_busy_rounded,
                            subtitle: 'Tap "Start Session" to begin a class',
                          )
                        : ListView.separated(
                            padding        : const EdgeInsets.all(16),
                            itemCount      : activeSessions.length,
                            separatorBuilder: (_, __) => const SizedBox(height: 12),
                            itemBuilder    : (context, i) =>
                                _ActiveSessionCard(
                                  session : activeSessions[i],
                                  onEnd   : () => _endSession(
                                    context, ref, activeSessions[i],
                                  ),
                                  onViewLogs: () => context.push(
                                    '/teacher/session-logs/${activeSessions[i]['id']}',
                                  ),
                                ),
                          ),

                    // Past sessions tab
                    pastSessions.isEmpty
                        ? const EmptyStateWidget(
                            message : 'No past sessions',
                            icon    : Icons.history_rounded,
                            subtitle: 'Completed sessions will appear here',
                          )
                        : ListView.separated(
                            padding        : const EdgeInsets.all(16),
                            itemCount      : pastSessions.length,
                            separatorBuilder: (_, __) => const SizedBox(height: 10),
                            itemBuilder    : (context, i) =>
                                _PastSessionCard(
                                  session    : pastSessions[i],
                                  onViewLogs : () => context.push(
                                    '/teacher/session-logs/${pastSessions[i]['id']}',
                                  ),
                                ),
                          ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  // ── Start session bottom sheet ───────────────────────────
  void _showStartSessionSheet(BuildContext context, WidgetRef ref) {
    showModalBottomSheet(
      context           : context,
      isScrollControlled: true,
      backgroundColor   : Colors.transparent,
      builder           : (_) => const _StartSessionSheet(),
    ).then((_) {
      ref.invalidate(mySessionsProvider);
    });
  }

  // ── End session with confirmation ────────────────────────
  Future<void> _endSession(
    BuildContext context,
    WidgetRef    ref,
    Map<String, dynamic> session,
  ) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title  : const Text('End Session?'),
        shape  : RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              session['subject_name']?.toString() ?? '',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 6),
            Text(
              'Present: ${session['present_count']} / ${session['total_students']} students\n'
              'Students who have not marked will be auto-marked Absent.',
              style: const TextStyle(color: AppColors.textSecondary),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child    : const Text('Cancel'),
          ),
          ElevatedButton(
            style    : ElevatedButton.styleFrom(
              backgroundColor: AppColors.danger,
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child    : const Text('End Session'),
          ),
        ],
      ),
    );

    if (confirmed != true || !context.mounted) return;

    final success = await ref
        .read(sessionActionProvider.notifier)
        .endSession(session['id'].toString());

    if (context.mounted) {
      final state = ref.read(sessionActionProvider);
      final msg   = state is SessionActionSuccess
          ? state.message
          : state is SessionActionError ? state.message : '';
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content        : Text(msg),
          backgroundColor: success ? AppColors.success : AppColors.danger,
        ),
      );
      ref.read(sessionActionProvider.notifier).reset();
    }
  }
}


// ══════════════════════════════════════════════════════════
// START SESSION BOTTOM SHEET
// ══════════════════════════════════════════════════════════

class _StartSessionSheet extends ConsumerStatefulWidget {
  const _StartSessionSheet();

  @override
  ConsumerState<_StartSessionSheet> createState() =>
      _StartSessionSheetState();
}

class _StartSessionSheetState extends ConsumerState<_StartSessionSheet> {
  final _formKey = GlobalKey<FormState>();

  Map<String, dynamic>? _selectedAllocation;
  Map<String, dynamic>? _selectedRoom;
  TimeOfDay _startTime = TimeOfDay.now();
  TimeOfDay _endTime   = TimeOfDay(
    hour  : TimeOfDay.now().hour + 1,
    minute: TimeOfDay.now().minute,
  );
  double _radius = 30.0;

  @override
  Widget build(BuildContext context) {
    final allocAsync   = ref.watch(teacherAllocationsProvider);
    final roomsAsync   = ref.watch(teacherRoomsProvider);

    final actionState  = ref.watch(sessionActionProvider);
    final isLoading    = actionState is SessionActionLoading;

    return Container(
      decoration: const BoxDecoration(
        color       : Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      padding: EdgeInsets.fromLTRB(
        24, 16, 24,
        MediaQuery.of(context).viewInsets.bottom + 24,
      ),
      child: SingleChildScrollView(
        child: Form(
          key : _formKey,
          child: Column(
            mainAxisSize     : MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              // Handle
              Center(
                child: Container(
                  width : 40, height: 4,
                  margin: const EdgeInsets.only(bottom: 20),
                  decoration: BoxDecoration(
                    color       : AppColors.borderColor,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),

              // Title
              const Text(
                'Start Attendance Session',
                style: TextStyle(
                  fontSize  : 20,
                  fontWeight: FontWeight.bold,
                  color     : AppColors.textPrimary,
                ),
              ),
              const SizedBox(height: 4),
              const Text(
                'Students must be inside the geo boundary to mark attendance.',
                style: TextStyle(
                  color  : AppColors.textSecondary,
                  fontSize: 13,
                ),
              ),
              const SizedBox(height: 20),

              // ── Subject dropdown ─────────────────────────
              const _FieldLabel('Subject'),
              allocAsync.when(
                loading: () => const LinearProgressIndicator(),
                error  : (e, _) => Text(
                  'Error loading subjects: $e',
                  style: const TextStyle(color: AppColors.danger),
                ),
                data   : (allocs) => allocs.isEmpty
                    ? Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color       : AppColors.warning.withOpacity(0.10),
                          borderRadius: BorderRadius.circular(10),
                          border      : Border.all(
                            color: AppColors.warning.withOpacity(0.30),
                          ),
                        ),
                        child: const Text(
                          'No subjects allocated. Contact your admin.',
                          style: TextStyle(color: AppColors.warning),
                        ),
                      )
                    : DropdownButtonFormField<Map<String, dynamic>>(
                        value    : _selectedAllocation,
                        hint     : const Text('Select subject'),
                        isExpanded: true,
                        decoration: const InputDecoration(),
                        items    : allocs.map((a) => DropdownMenuItem(
                          value: a,
                          child: Text(
                            '${a['subject_name']} — Div ${a['division_name']} Y${a['year_of_study']}',
                            overflow: TextOverflow.ellipsis,
                          ),
                        )).toList(),
                        onChanged: (v) =>
                            setState(() => _selectedAllocation = v),
                        validator: (v) =>
                            v == null ? 'Please select a subject' : null,
                      ),
              ),

              const SizedBox(height: 16),

              // ── Virtual room dropdown ────────────────────
              const _FieldLabel('Classroom (Virtual Room)'),
              roomsAsync.when(
                loading: () => const LinearProgressIndicator(),
                error  : (e, _) => Text(
                  'Error loading rooms: $e',
                  style: const TextStyle(color: AppColors.danger),
                ),
                data   : (rooms) => rooms.isEmpty
                    ? Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color       : AppColors.warning.withOpacity(0.10),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Text(
                          'No virtual rooms available. Contact your admin.',
                          style: TextStyle(color: AppColors.warning),
                        ),
                      )
                    : DropdownButtonFormField<Map<String, dynamic>>(
                        value    : _selectedRoom,
                        hint     : const Text('Select classroom'),
                        isExpanded: true,
                        decoration: const InputDecoration(),
                        items    : rooms.map((r) => DropdownMenuItem(
                          value: r,
                          child: Text(
                            '${r['name']} — ${r['building'] ?? ''} (${r['radius_meters']}m)',
                            overflow: TextOverflow.ellipsis,
                          ),
                        )).toList(),
                        onChanged: (v) => setState(() => _selectedRoom = v),
                        validator: (v) =>
                            v == null ? 'Please select a classroom' : null,
                      ),
              ),

              const SizedBox(height: 16),

              // ── Time pickers ─────────────────────────────
              const _FieldLabel('Session Time'),
              Row(
                children: [
                  Expanded(
                    child: _TimePicker(
                      label : 'Start',
                      time  : _startTime,
                      onPick: (t) => setState(() => _startTime = t),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _TimePicker(
                      label : 'End',
                      time  : _endTime,
                      onPick: (t) => setState(() => _endTime = t),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 16),

              // ── Radius slider ────────────────────────────
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const _FieldLabel('Geo Boundary Radius'),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10, vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color       : AppColors.primaryLight.withOpacity(0.10),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      '${_radius.round()}m',
                      style: const TextStyle(
                        color    : AppColors.primaryLight,
                        fontWeight: FontWeight.bold,
                        fontSize  : 14,
                      ),
                    ),
                  ),
                ],
              ),
              Slider(
                value      : _radius,
                min        : 10,
                max        : 100,
                divisions  : 18,
                label      : '${_radius.round()}m',
                activeColor: AppColors.primaryLight,
                onChanged  : (v) => setState(() => _radius = v),
              ),

              // ── Room info preview ────────────────────────
              if (_selectedRoom != null) ...[
                Container(
                  padding   : const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color       : AppColors.success.withOpacity(0.06),
                    borderRadius: BorderRadius.circular(10),
                    border      : Border.all(
                      color: AppColors.success.withOpacity(0.25),
                    ),
                  ),
                  child: Row(
                    children: [
                      const Icon(
                        Icons.location_on_rounded,
                        color: AppColors.success,
                        size : 18,
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          '${_selectedRoom!['name']} · '
                          'Center: ${_selectedRoom!['center_lat']}, '
                          '${_selectedRoom!['center_lng']}',
                          style: const TextStyle(
                            color  : AppColors.success,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
              ],

              const SizedBox(height: 8),

              // ── Submit button ────────────────────────────
              isLoading
                  ? const Center(
                      child: CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation(AppColors.success),
                      ),
                    )
                  : ElevatedButton.icon(
                      style    : ElevatedButton.styleFrom(
                        backgroundColor: AppColors.success,
                        minimumSize    : const Size(double.infinity, 52),
                        shape          : RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                      onPressed: _submit,
                      icon : const Icon(Icons.play_arrow_rounded),
                      label: const Text(
                        'Start Session',
                        style: TextStyle(
                          fontSize  : 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    final now   = DateTime.now();
    final start = DateTime(
      now.year, now.month, now.day,
      _startTime.hour, _startTime.minute,
    );
    final end = DateTime(
      now.year, now.month, now.day,
      _endTime.hour, _endTime.minute,
    );

    if (end.isBefore(start) || end.isAtSameMomentAs(start)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content        : Text('End time must be after start time.'),
          backgroundColor: AppColors.danger,
        ),
      );
      return;
    }

    final success = await ref
        .read(sessionActionProvider.notifier)
        .startSession({
      'subject_allocation_id': _selectedAllocation!['id'],
      'virtual_room_id'      : _selectedRoom!['id'],
      'scheduled_start'      : start.toIso8601String(),
      'scheduled_end'        : end.toIso8601String(),
      'lat'                  : _selectedRoom!['center_lat'],
      'lng'                  : _selectedRoom!['center_lng'],
      'radius_meters'        : _radius,
    });

    if (!mounted) return;

    final state = ref.read(sessionActionProvider);
    final msg   = state is SessionActionSuccess
        ? state.message
        : state is SessionActionError ? state.message : '';

    if (success) {
      Navigator.pop(context);
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content        : Text(msg),
        backgroundColor: success ? AppColors.success : AppColors.danger,
        duration       : const Duration(seconds: 4),
      ),
    );

    if (success) {
      ref.read(sessionActionProvider.notifier).reset();
    }
  }
}


// ══════════════════════════════════════════════════════════
// ACTIVE SESSION CARD
// ══════════════════════════════════════════════════════════

class _ActiveSessionCard extends StatelessWidget {
  final Map<String, dynamic> session;
  final VoidCallback         onEnd;
  final VoidCallback         onViewLogs;

  const _ActiveSessionCard({
    required this.session,
    required this.onEnd,
    required this.onViewLogs,
  });

  @override
  Widget build(BuildContext context) {
    final present = session['present_count'] as int? ?? 0;
    final total   = session['total_students'] as int? ?? 0;
    final pct     = session['attendance_pct'] as num? ?? 0;

    return Container(
      padding   : const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color       : AppColors.cardBg,
        borderRadius: BorderRadius.circular(16),
        border      : const Border(
          left  : BorderSide(color: AppColors.success, width: 4),
          top   : BorderSide(color: AppColors.borderColor),
          right : BorderSide(color: AppColors.borderColor),
          bottom: BorderSide(color: AppColors.borderColor),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          // ── Header ──────────────────────────────────
          Row(
            children: [
              _PulsingDot(),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 8, vertical: 3,
                ),
                decoration: BoxDecoration(
                  color       : AppColors.success.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: const Text(
                  'LIVE',
                  style: TextStyle(
                    color     : AppColors.success,
                    fontSize  : 11,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1,
                  ),
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10, vertical: 4,
                ),
                decoration: BoxDecoration(
                  color       : AppColors.bgSecondary,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  'Code: ${session['session_code']}',
                  style: const TextStyle(
                    fontFamily: 'monospace',
                    fontSize  : 13,
                    fontWeight: FontWeight.bold,
                    color     : AppColors.textPrimary,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 12),

          // Subject + Division
          Text(
            session['subject_name']?.toString() ?? '',
            style: const TextStyle(
              fontSize  : 17,
              fontWeight: FontWeight.w700,
              color     : AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            '${session['subject_code']} · '
            'Division ${session['division_name']} · '
            'Year ${session['year_of_study']} · '
            'Room: ${session['room_name'] ?? "N/A"}',
            style: const TextStyle(
              color  : AppColors.textSecondary,
              fontSize: 13,
            ),
          ),

          const SizedBox(height: 14),

          // ── Attendance progress bar ─────────────────
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          '$present / $total students present',
                          style: const TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize  : 14,
                            color     : AppColors.textPrimary,
                          ),
                        ),
                        Text(
                          '${pct.toStringAsFixed(1)}%',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize  : 14,
                            color     : AppColors.success,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child       : LinearProgressIndicator(
                        value          : total > 0 ? present / total : 0,
                        backgroundColor: AppColors.bgSecondary,
                        valueColor     : const AlwaysStoppedAnimation(
                          AppColors.success,
                        ),
                        minHeight      : 8,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 14),

          // ── Action buttons ───────────────────────────
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  style    : OutlinedButton.styleFrom(
                    foregroundColor: AppColors.primaryLight,
                    side           : const BorderSide(
                      color: AppColors.primaryLight,
                    ),
                    minimumSize: const Size(0, 44),
                  ),
                  onPressed: onViewLogs,
                  icon : const Icon(Icons.list_alt_rounded, size: 18),
                  label: const Text('View Logs'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: ElevatedButton.icon(
                  style    : ElevatedButton.styleFrom(
                    backgroundColor: AppColors.danger,
                    minimumSize    : const Size(0, 44),
                  ),
                  onPressed: onEnd,
                  icon : const Icon(Icons.stop_circle_rounded, size: 18),
                  label: const Text('End Session'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}


// ══════════════════════════════════════════════════════════
// PAST SESSION CARD
// ══════════════════════════════════════════════════════════

class _PastSessionCard extends StatelessWidget {
  final Map<String, dynamic> session;
  final VoidCallback         onViewLogs;

  const _PastSessionCard({
    required this.session,
    required this.onViewLogs,
  });

  @override
  Widget build(BuildContext context) {
    final present  = session['present_count']   as int?  ?? 0;
    final total    = session['total_students']   as int?  ?? 0;
    final pct      = session['attendance_pct']   as num?  ?? 0;
    final duration = session['duration_minutes'] as int?;

    final pctColor = pct >= 75
        ? AppColors.success
        : pct >= 60 ? AppColors.warning : AppColors.danger;

    return Container(
      padding   : const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color       : AppColors.cardBg,
        borderRadius: BorderRadius.circular(14),
        border      : Border.all(color: AppColors.borderColor),
      ),
      child: Row(
        children: [
          // Percentage circle
          SizedBox(
            width : 52, height: 52,
            child : Stack(
              alignment: Alignment.center,
              children : [
                CircularProgressIndicator(
                  value          : total > 0 ? present / total : 0,
                  backgroundColor: AppColors.bgSecondary,
                  color          : pctColor,
                  strokeWidth    : 4,
                ),
                Text(
                  '${pct.toStringAsFixed(0)}%',
                  style: TextStyle(
                    fontSize  : 11,
                    fontWeight: FontWeight.bold,
                    color     : pctColor,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(width: 12),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  session['subject_name']?.toString() ?? '',
                  style: const TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize  : 14,
                    color     : AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  'Div ${session['division_name']} · '
                  '${session['actual_start'] != null ? _formatDate(session['actual_start'].toString()) : ''}',
                  style: const TextStyle(
                    color  : AppColors.textSecondary,
                    fontSize: 12,
                  ),
                ),
                const SizedBox(height: 3),
                Row(
                  children: [
                    Text(
                      '$present/$total present',
                      style: TextStyle(
                        color    : pctColor,
                        fontSize : 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    if (duration != null) ...[
                      const Text(
                        ' · ',
                        style: TextStyle(color: AppColors.textSecondary),
                      ),
                      Text(
                        '${duration}min',
                        style: const TextStyle(
                          color  : AppColors.textSecondary,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),

          Column(
            children: [
              Text(
                'Code: ${session['session_code']}',
                style: const TextStyle(
                  color    : AppColors.textSecondary,
                  fontSize : 11,
                  fontFamily: 'monospace',
                ),
              ),
              const SizedBox(height: 6),
              TextButton(
                onPressed: onViewLogs,
                style    : TextButton.styleFrom(
                  minimumSize: const Size(0, 32),
                  padding    : const EdgeInsets.symmetric(horizontal: 10),
                ),
                child: const Text('Logs'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _formatDate(String isoString) {
    try {
      final dt = DateTime.parse(isoString).toLocal();
      return DateFormat('dd MMM, hh:mm a').format(dt);
    } catch (_) {
      return isoString;
    }
  }
}


// ── Helper widgets ─────────────────────────────────────────

class _FieldLabel extends StatelessWidget {
  final String text;
  const _FieldLabel(this.text);
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child  : Text(
        text,
        style: const TextStyle(
          fontSize  : 14,
          fontWeight: FontWeight.w600,
          color     : AppColors.textPrimary,
        ),
      ),
    );
  }
}

class _TimePicker extends StatelessWidget {
  final String    label;
  final TimeOfDay time;
  final Function(TimeOfDay) onPick;

  const _TimePicker({
    required this.label,
    required this.time,
    required this.onPick,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        final picked = await showTimePicker(
          context    : context,
          initialTime: time,
        );
        if (picked != null) onPick(picked);
      },
      child: Container(
        padding   : const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color       : AppColors.bgSecondary,
          borderRadius: BorderRadius.circular(12),
          border      : Border.all(color: AppColors.borderColor),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: const TextStyle(
              fontSize: 11, color: AppColors.textSecondary,
            )),
            const SizedBox(height: 4),
            Text(
              time.format(context),
              style: const TextStyle(
                fontWeight: FontWeight.w700,
                fontSize  : 16,
                color     : AppColors.textPrimary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PulsingDot extends StatefulWidget {
  @override
  State<_PulsingDot> createState() => _PulsingDotState();
}
class _PulsingDotState extends State<_PulsingDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double>   _anim;
  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 800),
    )..repeat(reverse: true);
    _anim = Tween(begin: 0.4, end: 1.0).animate(_ctrl);
  }
  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _anim,
      child  : Container(
        width: 10, height: 10,
        decoration: const BoxDecoration(
          color: AppColors.success, shape: BoxShape.circle,
        ),
      ),
    );
  }
}
