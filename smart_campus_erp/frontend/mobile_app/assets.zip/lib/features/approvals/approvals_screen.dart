import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/constants/app_colors.dart';
import '../../core/layout/app_layout.dart';
import '../../core/network/api_client.dart';
import '../../core/widgets/empty_state_widget.dart';
import '../../core/widgets/error_widget.dart';
import '../../core/widgets/loading_widget.dart';

// ── Provider ────────────────────────────────────────────────
final pendingApprovalsProvider =
    FutureProvider<Map<String, dynamic>>((ref) async {
  final api = ref.read(apiClientProvider);
  final res = await api.get('/api/auth/users/pending/');
  return Map<String, dynamic>.from(res.data as Map);
});

class ApprovalsScreen extends ConsumerWidget {
  const ApprovalsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(pendingApprovalsProvider);

    return AppLayout(
      title  : 'Pending Approvals',
      actions: [
        IconButton(
          icon     : const Icon(Icons.refresh_rounded),
          onPressed: () => ref.invalidate(pendingApprovalsProvider),
        ),
      ],
      child: async.when(
        loading: () => const LoadingWidget(message: 'Loading approvals...'),
        error  : (e, _) => AppErrorWidget(
          message: e.toString(),
          onRetry: () => ref.invalidate(pendingApprovalsProvider),
        ),
        data   : (data) {
          final users = List<Map<String, dynamic>>.from(
            data['pending_users'] as List,
          );
          final count = data['count'] as int? ?? 0;

          if (users.isEmpty) {
            return const EmptyStateWidget(
              message : 'No pending approvals',
              icon    : Icons.check_circle_rounded,
              subtitle: 'All users have been reviewed',
            );
          }

          return Column(
            children: [
              // Count banner
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 20, vertical: 12,
                ),
                color: AppColors.warning.withOpacity(0.08),
                child: Row(
                  children: [
                    const Icon(
                      Icons.pending_actions_rounded,
                      color: AppColors.warning,
                      size : 20,
                    ),
                    const SizedBox(width: 10),
                    Text(
                      '$count user${count == 1 ? '' : 's'} '
                      'awaiting approval',
                      style: const TextStyle(
                        color     : AppColors.warning,
                        fontWeight: FontWeight.w600,
                        fontSize  : 14,
                      ),
                    ),
                  ],
                ),
              ),

              Expanded(
                child: ListView.separated(
                  padding        : const EdgeInsets.all(16),
                  itemCount      : users.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder    : (context, i) {
                    return _ApprovalCard(
                      user  : users[i],
                      onApprove: () => _approve(context, ref, users[i]),
                      onReject : () => _rejectDialog(context, ref, users[i]),
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Future<void> _approve(
    BuildContext context,
    WidgetRef    ref,
    Map<String, dynamic> user,
  ) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title  : const Text('Approve User'),
        shape  : RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        content: Text(
          'Approve ${user['full_name']} as '
          '${_roleLabel(user['role'].toString())}?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child    : const Text('Cancel'),
          ),
          ElevatedButton(
            style    : ElevatedButton.styleFrom(
              backgroundColor: AppColors.success,
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child    : const Text('Approve'),
          ),
        ],
      ),
    );

    if (confirmed != true || !context.mounted) return;

    try {
      await ref.read(apiClientProvider).post(
        '/api/auth/users/${user['id']}/approve/',
      );
      ref.invalidate(pendingApprovalsProvider);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content        : Text('${user['full_name']} approved.'),
            backgroundColor: AppColors.success,
          ),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content        : Text('Error: $e'),
            backgroundColor: AppColors.danger,
          ),
        );
      }
    }
  }

  Future<void> _rejectDialog(
    BuildContext context,
    WidgetRef    ref,
    Map<String, dynamic> user,
  ) async {
    final reasonCtrl = TextEditingController();
    final formKey    = GlobalKey<FormState>();

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title  : const Text('Reject User'),
        shape  : RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        content: Form(
          key : formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Rejecting ${user['full_name']}. '
                'Please provide a reason:',
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller : reasonCtrl,
                maxLines   : 3,
                decoration : const InputDecoration(
                  hintText : 'Enter rejection reason...',
                  labelText: 'Reason',
                ),
                validator: (v) => (v == null || v.trim().length < 5)
                    ? 'Reason must be at least 5 characters'
                    : null,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child    : const Text('Cancel'),
          ),
          ElevatedButton(
            style    : ElevatedButton.styleFrom(
              backgroundColor: AppColors.danger,
            ),
            onPressed: () {
              if (formKey.currentState!.validate()) {
                Navigator.pop(ctx, true);
              }
            },
            child: const Text('Reject'),
          ),
        ],
      ),
    );

    if (confirmed != true || !context.mounted) return;

    try {
      await ref.read(apiClientProvider).post(
        '/api/auth/users/${user['id']}/reject/',
        data: {'reason': reasonCtrl.text.trim()},
      );
      ref.invalidate(pendingApprovalsProvider);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content        : Text('${user['full_name']} rejected.'),
            backgroundColor: AppColors.warning,
          ),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content        : Text('Error: $e'),
            backgroundColor: AppColors.danger,
          ),
        );
      }
    }
  }

  String _roleLabel(String role) => role.replaceAll('_', ' ').toUpperCase();
}


// ── Approval card widget ───────────────────────────────────
class _ApprovalCard extends StatelessWidget {
  final Map<String, dynamic> user;
  final VoidCallback         onApprove;
  final VoidCallback         onReject;

  const _ApprovalCard({
    required this.user,
    required this.onApprove,
    required this.onReject,
  });

  @override
  Widget build(BuildContext context) {
    final role        = user['role']?.toString() ?? '';
    final daysWaiting = user['days_waiting'] as int? ?? 0;

    return Container(
      padding   : const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color       : AppColors.cardBg,
        borderRadius: BorderRadius.circular(16),
        border      : const Border(
          left  : BorderSide(color: AppColors.warning, width: 4),
          top   : BorderSide(color: AppColors.borderColor),
          right : BorderSide(color: AppColors.borderColor),
          bottom: BorderSide(color: AppColors.borderColor),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          // ── Header ────────────────────────────────────
          Row(
            children: [
              CircleAvatar(
                radius         : 22,
                backgroundColor: AppColors.primaryLight.withOpacity(0.12),
                child          : Text(
                  _initials(user['full_name']?.toString() ?? ''),
                  style: const TextStyle(
                    color     : AppColors.primaryLight,
                    fontWeight: FontWeight.bold,
                    fontSize  : 14,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      user['full_name']?.toString() ?? '',
                      style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize  : 15,
                        color     : AppColors.textPrimary,
                      ),
                    ),
                    Text(
                      user['email']?.toString() ?? '',
                      style: const TextStyle(
                        color  : AppColors.textSecondary,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              // Days waiting badge
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 8, vertical: 4,
                ),
                decoration: BoxDecoration(
                  color       : daysWaiting > 2
                      ? AppColors.danger.withOpacity(0.10)
                      : AppColors.warning.withOpacity(0.10),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  daysWaiting == 0
                      ? 'Today'
                      : '$daysWaiting day${daysWaiting == 1 ? '' : 's'}',
                  style: TextStyle(
                    color    : daysWaiting > 2
                        ? AppColors.danger
                        : AppColors.warning,
                    fontSize : 11,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 12),

          // ── Info chips ────────────────────────────────
          Wrap(
            spacing: 8,
            children: [
              _InfoChip(
                label: role.replaceAll('_', ' ').toUpperCase(),
                color: AppColors.primaryLight,
              ),
              if (user['phone'] != null && user['phone'] != '')
                _InfoChip(
                  label: user['phone'].toString(),
                  color: AppColors.textSecondary,
                ),
            ],
          ),

          const SizedBox(height: 14),

          // ── Action buttons ────────────────────────────
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  style    : OutlinedButton.styleFrom(
                    foregroundColor: AppColors.danger,
                    side           : const BorderSide(color: AppColors.danger),
                    minimumSize    : const Size(0, 44),
                    shape          : RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  onPressed: onReject,
                  icon : const Icon(Icons.close_rounded, size: 18),
                  label: const Text('Reject'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                flex  : 2,
                child : ElevatedButton.icon(
                  style    : ElevatedButton.styleFrom(
                    backgroundColor: AppColors.success,
                    minimumSize    : const Size(0, 44),
                    shape          : RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  onPressed: onApprove,
                  icon : const Icon(Icons.check_rounded, size: 18),
                  label: const Text('Approve'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _initials(String name) {
    final parts = name.trim().split(' ');
    if (parts.length >= 2) {
      return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    }
    return name.isNotEmpty ? name[0].toUpperCase() : '?';
  }
}

class _InfoChip extends StatelessWidget {
  final String label;
  final Color  color;
  const _InfoChip({required this.label, required this.color});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color       : color.withOpacity(0.10),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        label,
        style: TextStyle(
          color    : color,
          fontSize : 12,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}
