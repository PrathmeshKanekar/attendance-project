import 'dart:convert';
import 'dart:io' as io;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:camera/camera.dart';
import 'package:file_picker/file_picker.dart';

import '../../core/constants/app_colors.dart';
import '../../core/config/api_config.dart';
import '../../core/network/dio_client.dart';

// ─────────────────────────────────────────────────────────────────────────────
// Design tokens — everything uses these so the form is always visible.
// Swap with AppColors once you've confirmed the screen works.
// ─────────────────────────────────────────────────────────────────────────────
class _C {
  static const primary        = Color(0xFF1A3A5C); // dark navy
  static const primaryLight   = Color(0xFF2563EB); // blue
  static const success        = Color(0xFF16A34A);
  static const danger         = Color(0xFFDC2626);
  static const warning        = Color(0xFFD97706);
  static const bgPage         = Color(0xFFF1F5F9); // light gray page bg
  static const bgCard         = Colors.white;
  static const bgField        = Color(0xFFF8FAFC);
  static const border         = Color(0xFFCBD5E1);
  static const textPrimary    = Color(0xFF0F172A);
  static const textSecondary  = Color(0xFF64748B);
  static const stepDone       = Color(0xFF16A34A);
  static const stepActive     = Color(0xFF1A3A5C);
  static const stepInactive   = Color(0xFFE2E8F0);
}

// ─────────────────────────────────────────────────────────────────────────────
// Stub providers — replace bodies with real API calls when backend is ready
// ─────────────────────────────────────────────────────────────────────────────
final _regCollegesProvider =
    FutureProvider<List<Map<String, dynamic>>>((ref) async => []);
final _regDepartmentsProvider =
    FutureProvider<List<Map<String, dynamic>>>((ref) async => []);
final _regCoursesProvider =
    FutureProvider<List<Map<String, dynamic>>>((ref) async => []);
final _regDivisionsProvider =
    FutureProvider<List<Map<String, dynamic>>>((ref) async => []);
final _regAcadYearsProvider =
    FutureProvider<List<Map<String, dynamic>>>((ref) async => []);

// ─────────────────────────────────────────────────────────────────────────────

class RegistrationScreen extends ConsumerStatefulWidget {
  const RegistrationScreen({super.key});

  @override
  ConsumerState<RegistrationScreen> createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends ConsumerState<RegistrationScreen> {
  // ── Step tracking ────────────────────────────────────────────────────────
  int  _currentStep  = 0;
  bool _isSubmitting = false;

  final _formKey = GlobalKey<FormState>();

  static const _stepTitles = [
    'Personal', 'Academic', 'Credentials',
    'Biometrics', 'Documents', 'Review',
  ];

  // ── Step 1 controllers ───────────────────────────────────────────────────
  final _fNameCtrl    = TextEditingController();
  final _mNameCtrl    = TextEditingController();
  final _lNameCtrl    = TextEditingController();
  final _emailCtrl    = TextEditingController();
  final _phoneCtrl    = TextEditingController();
  final _altPhoneCtrl = TextEditingController();
  final _addressCtrl  = TextEditingController();
  final _cityCtrl     = TextEditingController();
  final _stateCtrl    = TextEditingController();
  final _pincodeCtrl  = TextEditingController();
  String?   _selectedGender;
  String?   _selectedBloodGroup;
  DateTime? _selectedDob;

  // ── Step 2 controllers ───────────────────────────────────────────────────
  final _prnCtrl           = TextEditingController();
  final _rollCtrl          = TextEditingController();
  final _enrollmentCtrl    = TextEditingController();
  final _batchCtrl         = TextEditingController();
  final _admissionYearCtrl = TextEditingController();
  final _yearOfStudyCtrl   = TextEditingController();
  String? _selectedCollegeId;
  String? _selectedDeptId;
  String? _selectedCourseId;
  String? _selectedDivisionId;
  String? _selectedAcadYearId;

  // ── Step 3 ───────────────────────────────────────────────────────────────
  final _passwordCtrl        = TextEditingController();
  final _confirmPasswordCtrl = TextEditingController();
  bool _obscurePassword        = true;
  bool _obscureConfirmPassword = true;

  // ── Step 4 ───────────────────────────────────────────────────────────────
  XFile?            _faceFront;
  XFile?            _faceLeft;
  XFile?            _faceRight;
  String            _activeFaceAngle      = 'front';
  CameraController? _cameraController;
  bool              _isCameraInitializing = false;

  // ── Step 5 ───────────────────────────────────────────────────────────────
  final List<Map<String, dynamic>> _uploadedDocs = [];
  final List<String> _docTypes = [
    'Aadhaar Card', 'Student ID Card',
    'Admission Receipt', 'Supporting Marksheet',
  ];

  // ── Step 6 ───────────────────────────────────────────────────────────────
  bool _agreeTerms   = false;
  bool _agreePrivacy = false;

  // ── Duplicate check ──────────────────────────────────────────────────────
  bool    _isCheckingDuplicates    = false;
  String? _duplicateEmailError;
  String? _duplicatePrnError;
  String? _duplicateEnrollmentError;

  // ─────────────────────────────────────────────────────────────────────────
  // Lifecycle
  // ─────────────────────────────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();
    _admissionYearCtrl.text = DateTime.now().year.toString();
    _yearOfStudyCtrl.text   = '1';
  }

  @override
  void dispose() {
    for (final c in [
      _fNameCtrl, _mNameCtrl, _lNameCtrl, _emailCtrl, _phoneCtrl,
      _altPhoneCtrl, _addressCtrl, _cityCtrl, _stateCtrl, _pincodeCtrl,
      _prnCtrl, _rollCtrl, _enrollmentCtrl, _batchCtrl,
      _admissionYearCtrl, _yearOfStudyCtrl,
      _passwordCtrl, _confirmPasswordCtrl,
    ]) { c.dispose(); }
    _cameraController?.dispose();
    super.dispose();
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Navigation
  // ─────────────────────────────────────────────────────────────────────────
  void _goBack() {
    _cameraController?.dispose();
    _cameraController = null;
    setState(() => _currentStep--);
  }

  Future<void> _goNext() async {
    if (!(_formKey.currentState?.validate() ?? true)) return;

    switch (_currentStep) {
      case 0:
        if (_selectedDob == null) return _snack('Please select your Date of Birth.');
        if (DateTime.now().year - _selectedDob!.year < 16)
          return _snack('Minimum age for registration is 16 years.');
        break;
      case 1:
        if ([_selectedCollegeId, _selectedDeptId, _selectedCourseId,
             _selectedAcadYearId, _selectedDivisionId].any((v) => v == null))
          return _snack('Please select all academic dropdown fields.');
        break;
      case 2:
        if (_passwordCtrl.text != _confirmPasswordCtrl.text)
          return _snack('Passwords do not match.', isError: true);
        if (!await _verifyDuplicates()) return;
        break;
      case 3:
        if (_faceFront == null)
          return _snack('Please capture a front-facing photo.');
        break;
      case 4:
        if (_uploadedDocs.isEmpty)
          return _snack('Please upload at least one identification document.');
        break;
    }
    setState(() => _currentStep++);
  }

  void _snack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content        : Text(msg),
      backgroundColor: isError ? _C.danger : null,
      behavior       : SnackBarBehavior.floating,
    ));
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Camera
  // ─────────────────────────────────────────────────────────────────────────
  Future<void> _startCamera(String angle) async {
    setState(() { _activeFaceAngle = angle; _isCameraInitializing = true; });
    try {
      final cams  = await availableCameras();
      final front = cams.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.front,
        orElse: () => cams.first,
      );
      _cameraController =
          CameraController(front, ResolutionPreset.medium, enableAudio: false);
      await _cameraController!.initialize();
    } catch (e) {
      _snack('Camera error: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isCameraInitializing = false);
    }
  }

  Future<void> _snapPhoto() async {
    if (_cameraController == null || !_cameraController!.value.isInitialized) return;
    try {
      final photo = await _cameraController!.takePicture();
      setState(() {
        if (_activeFaceAngle == 'front')      _faceFront = photo;
        else if (_activeFaceAngle == 'left')  _faceLeft  = photo;
        else                                  _faceRight = photo;
      });
      await _cameraController!.dispose();
      _cameraController = null;
    } catch (e) {
      _snack('Capture failed: $e', isError: true);
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Document picker
  // ─────────────────────────────────────────────────────────────────────────
  Future<void> _pickDocument(String docType) async {
    try {
      final result = await FilePicker.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf', 'jpg', 'jpeg', 'png'],
        withData: true,
      );
      if (result == null || result.files.isEmpty) return;
      final file = result.files.first;
      if (file.size > 4 * 1024 * 1024)
        return _snack('Maximum file size is 4 MB.', isError: true);
      final bytes = file.bytes ??
          (file.path != null ? await io.File(file.path!).readAsBytes() : null);
      if (bytes == null) return;
      setState(() {
        _uploadedDocs.removeWhere((d) => d['document_type'] == docType);
        _uploadedDocs.add({
          'document_type': docType,
          'file_name'    : file.name,
          'file_b64'     : base64Encode(bytes),
          'file_size'    : file.size,
        });
      });
    } catch (e) {
      _snack('File error: $e', isError: true);
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Duplicate check & submit
  // ─────────────────────────────────────────────────────────────────────────
  Future<bool> _verifyDuplicates() async {
    setState(() {
      _isCheckingDuplicates    = true;
      _duplicateEmailError      = null;
      _duplicatePrnError        = null;
      _duplicateEnrollmentError = null;
    });
    try {
      final dio = ref.read(dioClientProvider);
      final res = await dio.get('/api/students/check-duplicate/', params: {
        'email'            : _emailCtrl.text.trim(),
        'prn'              : _prnCtrl.text.trim().toUpperCase(),
        'enrollment_number': _enrollmentCtrl.text.trim().toUpperCase(),
      });
      final data = res.data as Map<String, dynamic>;
      setState(() {
        if (data['email_exists'] == true)
          _duplicateEmailError = 'A user with this email already exists.';
        if (data['prn_exists'] == true)
          _duplicatePrnError = 'This PRN is already registered.';
        if (data['enrollment_number_exists'] == true)
          _duplicateEnrollmentError = 'This Enrollment Number is already registered.';
        _isCheckingDuplicates = false;
      });
      return _duplicateEmailError == null &&
             _duplicatePrnError == null &&
             _duplicateEnrollmentError == null;
    } catch (e) {
      setState(() => _isCheckingDuplicates = false);
      _snack('Duplicate check failed. Check your connection.');
      return false;
    }
  }

  Future<void> _submitRegistration() async {
    if (!_agreeTerms || !_agreePrivacy)
      return _snack('Please accept the terms and privacy policy.');
    setState(() => _isSubmitting = true);
    try {
      final frontBytes = await _faceFront!.readAsBytes();
      String? leftB64, rightB64;
      if (_faceLeft  != null) leftB64  = base64Encode(await _faceLeft!.readAsBytes());
      if (_faceRight != null) rightB64 = base64Encode(await _faceRight!.readAsBytes());

      final dio = ref.read(dioClientProvider);
      await dio.post(ApiConfig.studentsRegister, data: {
        'email'               : _emailCtrl.text.trim(),
        'first_name'          : _fNameCtrl.text.trim(),
        'middle_name'         : _mNameCtrl.text.trim(),
        'last_name'           : _lNameCtrl.text.trim(),
        'gender'              : _selectedGender,
        'date_of_birth'       : _selectedDob?.toIso8601String().split('T').first,
        'blood_group'         : _selectedBloodGroup,
        'phone'               : _phoneCtrl.text.trim(),
        'alternate_phone'     : _altPhoneCtrl.text.trim(),
        'address'             : _addressCtrl.text.trim(),
        'city'                : _cityCtrl.text.trim(),
        'state'               : _stateCtrl.text.trim(),
        'pincode'             : _pincodeCtrl.text.trim(),
        'prn'                 : _prnCtrl.text.trim().toUpperCase(),
        'roll_number'         : _rollCtrl.text.trim(),
        'enrollment_number'   : _enrollmentCtrl.text.trim().toUpperCase(),
        'college_id'          : _selectedCollegeId,
        'course_id'           : _selectedCourseId,
        'division_id'         : _selectedDivisionId,
        'academic_year_id'    : _selectedAcadYearId,
        'batch'               : _batchCtrl.text.trim(),
        'admission_year'      : int.tryParse(_admissionYearCtrl.text) ?? DateTime.now().year,
        'year_of_study'       : int.tryParse(_yearOfStudyCtrl.text) ?? 1,
        'password'            : _passwordCtrl.text,
        'face_image_b64'      : base64Encode(frontBytes),
        'face_image_left_b64' : leftB64,
        'face_image_right_b64': rightB64,
        'uploaded_documents'  : _uploadedDocs,
      });
      if (!mounted) return;
      showDialog(
        context          : context,
        barrierDismissible: false,
        builder: (_) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: const Row(children: [
            Icon(Icons.check_circle, color: _C.success, size: 28),
            SizedBox(width: 8),
            Text('Registration Pending'),
          ]),
          content: const Text(
            'Your registration has been submitted.\n\n'
            'A Lab Assistant will verify your biometrics and documents shortly.',
          ),
          actions: [
            ElevatedButton(
              onPressed: () { Navigator.pop(context); context.go('/login'); },
              style    : ElevatedButton.styleFrom(backgroundColor: _C.primary),
              child    : const Text('Return to Login'),
            ),
          ],
        ),
      );
    } catch (e) {
      _snack('Registration failed: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // BUILD — fixed layout that ALWAYS shows content
  // ─────────────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Use a concrete color — never AppColors.bgPrimary in case it's transparent
      backgroundColor: _C.bgPage,
      appBar: AppBar(
        backgroundColor      : _C.primary,
        foregroundColor      : Colors.white,
        automaticallyImplyLeading: false,
        title: const Text(
          'Campus ERP Registration',
          style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17),
        ),
        leading: _currentStep > 0
            ? IconButton(icon: const Icon(Icons.arrow_back), onPressed: _goBack)
            : IconButton(
                icon: const Icon(Icons.close),
                onPressed: () => context.go('/login'),
              ),
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 800),
          child: Column(
            children: [
              // ── Progress HUD (always visible, fixed height) ────────────
              Container(
                color  : _C.bgCard,
                padding: const EdgeInsets.fromLTRB(12, 14, 12, 10),
                child  : _progressHud(),
              ),
              Container(height: 1, color: _C.border),

              // ── Step content (Expanded forces it to fill all remaining space)
              Expanded(
                child: SingleChildScrollView(
                  // Explicit white background so content is always visible
                  // regardless of theme / AppColors issues
                  child: Container(
                    color  : _C.bgPage,
                    padding: const EdgeInsets.all(20),
                    child  : Form(
                      key : _formKey,
                      child: _currentStepWidget(),
                    ),
                  ),
                ),
              ),

              // ── Bottom nav (always visible, fixed height) ──────────────
              _navBar(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _currentStepWidget() {
    switch (_currentStep) {
      case 0:  return _personalStep();
      case 1:  return _academicStep();
      case 2:  return _accountStep();
      case 3:  return _faceStep();
      case 4:  return _documentStep();
      case 5:  return _reviewStep();
      default: return const SizedBox.shrink();
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Step 1 — Personal
  // ─────────────────────────────────────────────────────────────────────────
  Widget _personalStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _sectionHeader(Icons.person_outline, 'Personal Profile'),
        const SizedBox(height: 20),

        // Name row
        _label('Full Name *'),
        const SizedBox(height: 6),
        LayoutBuilder(
  builder: (context, constraints) {
    final mobile = constraints.maxWidth < 700;

    if (mobile) {
      return Column(
        children: [
          _tf(_fNameCtrl, 'First Name',
              validator: _req('First name')),
          const SizedBox(height: 12),

          _tf(_mNameCtrl, 'Middle Name'),
          const SizedBox(height: 12),

          _tf(_lNameCtrl, 'Last Name',
              validator: _req('Last name')),
        ],
      );
    }

    return Row(
      children: [
        Expanded(
          child: _tf(_fNameCtrl, 'First Name',
              validator: _req('First name')),
        ),
        const SizedBox(width: 10),

        Expanded(
          child: _tf(_mNameCtrl, 'Middle Name'),
        ),
        const SizedBox(width: 10),

        Expanded(
          child: _tf(_lNameCtrl, 'Last Name',
              validator: _req('Last name')),
        ),
      ],
    );
  },
),
        const SizedBox(height: 16),

        // Gender + Blood group
        Row(children: [
          Expanded(child: _dropdown<String>(
            label    : 'Gender *',
            value    : _selectedGender,
            items    : ['Male', 'Female', 'Other'],
            onChanged: (v) => setState(() => _selectedGender = v),
            validator: (v) => v == null ? 'Required' : null,
          )),
          const SizedBox(width: 10),
          Expanded(child: _dropdown<String>(
            label    : 'Blood Group',
            value    : _selectedBloodGroup,
            items    : ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'],
            onChanged: (v) => setState(() => _selectedBloodGroup = v),
          )),
        ]),
        const SizedBox(height: 16),

        // DOB + Phone
        Row(children: [
          Expanded(child: _dobPicker()),
          const SizedBox(width: 10),
          Expanded(child: _tf(_phoneCtrl, 'Mobile Number *',
              keyboard : TextInputType.phone,
              validator: (v) => (v == null || v.length < 10)
                  ? 'Enter valid 10-digit number' : null)),
        ]),
        const SizedBox(height: 16),

        _tf(_emailCtrl, 'Email Address *',
            keyboard  : TextInputType.emailAddress,
            errorText : _duplicateEmailError,
            validator : (v) =>
                (v == null || !v.contains('@')) ? 'Invalid email' : null),
        const SizedBox(height: 16),

        _tf(_altPhoneCtrl, 'Alternate Contact',
            keyboard: TextInputType.phone),
        const SizedBox(height: 16),

        _tf(_addressCtrl, 'Residential Address *',
            maxLines : 2,
            validator: _req('Address')),
        const SizedBox(height: 16),

        Row(children: [
          Expanded(child: _tf(_cityCtrl,    'City *',    validator: _req('City'))),
          const SizedBox(width: 10),
          Expanded(child: _tf(_stateCtrl,   'State *',   validator: _req('State'))),
          const SizedBox(width: 10),
          Expanded(child: _tf(_pincodeCtrl, 'Pincode *',
              keyboard : TextInputType.number,
              validator: (v) => (v == null || v.trim().length < 6)
                  ? 'Min 6 digits' : null)),
        ]),
        const SizedBox(height: 8),
      ],
    );
  }

  Widget _dobPicker() {
    return GestureDetector(
      onTap: () async {
        final picked = await showDatePicker(
          context    : context,
          initialDate: DateTime.now().subtract(const Duration(days: 365 * 18)),
          firstDate  : DateTime(1990),
          lastDate   : DateTime.now(),
        );
        if (picked != null) setState(() => _selectedDob = picked);
      },
      child: Container(
        height     : 56,
        padding    : const EdgeInsets.symmetric(horizontal: 12),
        decoration : BoxDecoration(
          color       : _C.bgField,
          border      : Border.all(color: _C.border),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(children: [
          const Icon(Icons.calendar_month, color: _C.textSecondary, size: 18),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              _selectedDob == null
                  ? 'Date of Birth *'
                  : '${_selectedDob!.day}/${_selectedDob!.month}/${_selectedDob!.year}',
              style: TextStyle(
                fontSize: 14,
                color   : _selectedDob == null
                    ? _C.textSecondary : _C.textPrimary,
              ),
            ),
          ),
        ]),
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Step 2 — Academic
  // ─────────────────────────────────────────────────────────────────────────
  Widget _academicStep() {
    final collegesAsync      = ref.watch(_regCollegesProvider);
    final departmentsAsync   = ref.watch(_regDepartmentsProvider);
    final coursesAsync       = ref.watch(_regCoursesProvider);
    final divisionsAsync     = ref.watch(_regDivisionsProvider);
    final academicYearsAsync = ref.watch(_regAcadYearsProvider);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _sectionHeader(Icons.school_outlined, 'Academic Enrollment'),
        const SizedBox(height: 20),

        _asyncDropdown(
          asyncValue: collegesAsync, label: 'College / Institution *',
          icon: Icons.apartment,
          value: _selectedCollegeId,
          onChanged: (v) => setState(() => _selectedCollegeId = v),
          validator: (v) => v == null ? 'College is required' : null,
        ),
        const SizedBox(height: 16),

        _asyncDropdown(
          asyncValue: departmentsAsync, label: 'Department *',
          icon: Icons.account_tree_outlined,
          value: _selectedDeptId,
          onChanged: (v) => setState(() {
            _selectedDeptId = v; _selectedCourseId = null;
          }),
          validator: (v) => v == null ? 'Department is required' : null,
        ),
        const SizedBox(height: 16),

        _asyncDropdown(
          asyncValue: coursesAsync, label: 'Academic Program (Course) *',
          icon: Icons.import_contacts_outlined,
          value: _selectedCourseId,
          filterKey: 'department_id', filterValue: _selectedDeptId,
          onChanged: (v) => setState(() => _selectedCourseId = v),
          validator: (v) => v == null ? 'Course is required' : null,
        ),
        const SizedBox(height: 16),

        _asyncDropdown(
          asyncValue: academicYearsAsync, label: 'Academic Year *',
          icon: Icons.event_note,
          value: _selectedAcadYearId,
          onChanged: (v) => setState(() => _selectedAcadYearId = v),
          validator: (v) => v == null ? 'Academic Year is required' : null,
        ),
        const SizedBox(height: 16),

        _asyncDropdown(
          asyncValue: divisionsAsync, label: 'Division (Classroom) *',
          icon: Icons.groups_outlined,
          value: _selectedDivisionId,
          filterKey: 'course_id', filterValue: _selectedCourseId,
          onChanged: (v) => setState(() => _selectedDivisionId = v),
          validator: (v) => v == null ? 'Division is required' : null,
        ),
        const SizedBox(height: 16),

        Row(children: [
          Expanded(
            flex: 2,
            child: _tf(_prnCtrl, 'PRN Number *',
                errorText: _duplicatePrnError,
                validator: _req('PRN')),
          ),
          const SizedBox(width: 10),
          Expanded(child: _tf(_rollCtrl, 'Roll No *',
              keyboard: TextInputType.number,
              validator: _req('Roll No'))),
        ]),
        const SizedBox(height: 16),

        Row(children: [
          Expanded(child: _tf(_enrollmentCtrl, 'Enrollment Number *',
              errorText: _duplicateEnrollmentError,
              validator: _req('Enrollment No'))),
          const SizedBox(width: 10),
          Expanded(child: _tf(_batchCtrl, 'Batch (e.g. B1)')),
        ]),
        const SizedBox(height: 16),

        Row(children: [
          Expanded(child: _tf(_admissionYearCtrl, 'Admission Year *',
              keyboard : TextInputType.number,
              validator: (v) =>
                  int.tryParse(v ?? '') == null ? 'Enter valid year' : null)),
          const SizedBox(width: 10),
          Expanded(child: _tf(_yearOfStudyCtrl, 'Year of Study (1-4) *',
              keyboard : TextInputType.number,
              validator: (v) =>
                  int.tryParse(v ?? '') == null ? 'Enter number' : null)),
        ]),
        const SizedBox(height: 8),
      ],
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Step 3 — Account
  // ─────────────────────────────────────────────────────────────────────────
  Widget _accountStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _sectionHeader(Icons.security_outlined, 'Account Credentials'),
        const SizedBox(height: 20),

        _tf(_emailCtrl, 'Username (same as email)', enabled: false),
        const SizedBox(height: 16),

        TextFormField(
          controller : _passwordCtrl,
          obscureText: _obscurePassword,
          onChanged  : (_) => setState(() {}),
          style      : const TextStyle(color: _C.textPrimary),
          decoration : _inputDec('Password *',
              suffix: IconButton(
                icon: Icon(
                  _obscurePassword ? Icons.visibility_off : Icons.visibility,
                  color: _C.textSecondary, size: 20,
                ),
                onPressed: () =>
                    setState(() => _obscurePassword = !_obscurePassword),
              )),
          validator: (v) {
            if (v == null || v.isEmpty)                          return 'Password is required';
            if (v.length < 8)                                    return 'Min 8 characters';
            if (!v.contains(RegExp(r'[A-Z]')))                   return 'Need 1 uppercase letter';
            if (!v.contains(RegExp(r'[a-z]')))                   return 'Need 1 lowercase letter';
            if (!v.contains(RegExp(r'[0-9]')))                   return 'Need 1 digit';
            if (!v.contains(RegExp(r'[!@#$%^&*(),.?":{}|<>]')))  return 'Need 1 special character';
            return null;
          },
        ),
        const SizedBox(height: 8),
        _passwordStrengthBar(),
        const SizedBox(height: 16),

        TextFormField(
          controller : _confirmPasswordCtrl,
          obscureText: _obscureConfirmPassword,
          style      : const TextStyle(color: _C.textPrimary),
          decoration : _inputDec('Confirm Password *',
              suffix: IconButton(
                icon: Icon(
                  _obscureConfirmPassword ? Icons.visibility_off : Icons.visibility,
                  color: _C.textSecondary, size: 20,
                ),
                onPressed: () => setState(
                    () => _obscureConfirmPassword = !_obscureConfirmPassword),
              )),
          validator: (v) =>
              v != _passwordCtrl.text ? 'Passwords do not match' : null,
        ),
        const SizedBox(height: 8),
      ],
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Step 4 — Face
  // ─────────────────────────────────────────────────────────────────────────
  Widget _faceStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _sectionHeader(Icons.face_retouching_natural, 'Biometric Face Registration'),
        const SizedBox(height: 8),
        const Text(
          'Capture your face from 3 angles for reliable attendance verification.',
          style: TextStyle(fontSize: 13, color: _C.textSecondary),
        ),
        const SizedBox(height: 24),

        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _angleTile('front', _faceFront, 'Front'),
            _angleTile('left',  _faceLeft,  'Left'),
            _angleTile('right', _faceRight, 'Right'),
          ],
        ),
        const SizedBox(height: 28),

        Center(
          child: Container(
            width : 280,
            height: 280,
            decoration: BoxDecoration(
              color : const Color(0xFFF1F5F9),
              shape : BoxShape.circle,
              border: Border.all(color: _C.primaryLight, width: 3),
            ),
            child: ClipOval(
              child: _isCameraInitializing
                  ? const Center(child: CircularProgressIndicator())
                  : (_cameraController != null &&
                          _cameraController!.value.isInitialized
                      ? CameraPreview(_cameraController!)
                      : _cameraPlaceholder()),
            ),
          ),
        ),
        const SizedBox(height: 24),

        Center(
          child: _cameraController == null
              ? ElevatedButton.icon(
                  onPressed: () => _startCamera(_activeFaceAngle),
                  icon : const Icon(Icons.videocam_outlined),
                  label: Text('Open Camera – $_activeFaceAngle angle'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _C.primaryLight,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  ),
                )
              : ElevatedButton.icon(
                  onPressed: _snapPhoto,
                  icon : const Icon(Icons.camera_alt),
                  label: const Text('Capture Photo'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _C.primary,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  ),
                ),
        ),
        const SizedBox(height: 8),
      ],
    );
  }

  Widget _angleTile(String angle, XFile? file, String label) {
    final active = _activeFaceAngle == angle;
    return GestureDetector(
      onTap: () {
        _cameraController?.dispose();
        _cameraController = null;
        _startCamera(angle);
      },
      child: Column(children: [
        Container(
          width : 68, height: 68,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: active ? _C.primaryLight.withOpacity(0.08) : _C.bgField,
            border: Border.all(
              color: active ? _C.primaryLight
                  : (file != null ? _C.success : _C.border),
              width: 2.5,
            ),
          ),
          child: file != null
              ? ClipRRect(
                  borderRadius: BorderRadius.circular(34),
                  child       : kIsWeb
                      ? Image.network(file.path, fit: BoxFit.cover)
                      : Image.file(io.File(file.path), fit: BoxFit.cover),
                )
              : Icon(Icons.face_outlined,
                  color: active ? _C.primaryLight : _C.textSecondary,
                  size : 28),
        ),
        const SizedBox(height: 6),
        Text(label,
            style: TextStyle(
              fontSize  : 12,
              fontWeight: FontWeight.bold,
              color     : active ? _C.primaryLight : _C.textPrimary,
            )),
        if (file != null)
          const Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.check_circle, color: _C.success, size: 12),
            SizedBox(width: 2),
            Text('Ready',
                style: TextStyle(color: _C.success, fontSize: 10,
                    fontWeight: FontWeight.bold)),
          ]),
      ]),
    );
  }

  Widget _cameraPlaceholder() {
    final msgs = {
      'front': 'Look straight ahead',
      'left' : 'Tilt head to the left',
      'right': 'Tilt head to the right',
    };
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child  : Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Icon(Icons.face_retouching_natural,
              size: 52, color: _C.textSecondary),
          const SizedBox(height: 12),
          Text(
            msgs[_activeFaceAngle] ?? 'Tap angle above, then Open Camera',
            style: const TextStyle(fontSize: 13, color: _C.textSecondary,
                fontWeight: FontWeight.w600),
            textAlign: TextAlign.center,
          ),
        ]),
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Step 5 — Documents
  // ─────────────────────────────────────────────────────────────────────────
  Widget _documentStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _sectionHeader(Icons.upload_file_outlined, 'Document Upload'),
        const SizedBox(height: 8),
        const Text(
          'Max 4 MB per file. Accepted: PDF, JPG, PNG.',
          style: TextStyle(fontSize: 13, color: _C.textSecondary),
        ),
        const SizedBox(height: 20),
        ..._docTypes.map((type) {
          final doc      = _uploadedDocs.firstWhere(
              (d) => d['document_type'] == type, orElse: () => {});
          final uploaded = doc.isNotEmpty;
          return Container(
            margin     : const EdgeInsets.only(bottom: 12),
            padding    : const EdgeInsets.all(14),
            decoration : BoxDecoration(
              color       : _C.bgCard,
              borderRadius: BorderRadius.circular(12),
              border      : Border.all(
                color: uploaded ? _C.success.withOpacity(0.5) : _C.border,
              ),
            ),
            child: Row(children: [
              Icon(
                uploaded ? Icons.check_circle : Icons.insert_drive_file_outlined,
                color: uploaded ? _C.success : _C.textSecondary,
                size : 28,
              ),
              const SizedBox(width: 12),
              Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(type,
                      style: const TextStyle(
                          fontSize: 14, fontWeight: FontWeight.bold,
                          color: _C.textPrimary)),
                  const SizedBox(height: 2),
                  Text(
                    uploaded
                        ? '${doc['file_name']}  '
                          '(${(doc['file_size'] / 1024).toStringAsFixed(1)} KB)'
                        : 'Not uploaded',
                    style: TextStyle(
                        fontSize: 12,
                        color   : uploaded ? _C.success : _C.textSecondary),
                  ),
                ],
              )),
              TextButton.icon(
                onPressed: () => _pickDocument(type),
                icon : Icon(uploaded ? Icons.refresh : Icons.upload,
                    size: 16, color: _C.primaryLight),
                label: Text(uploaded ? 'Replace' : 'Upload',
                    style: const TextStyle(color: _C.primaryLight)),
              ),
            ]),
          );
        }),
        const SizedBox(height: 8),
      ],
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Step 6 — Review
  // ─────────────────────────────────────────────────────────────────────────
  Widget _reviewStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _sectionHeader(Icons.fact_check_outlined, 'Final Review'),
        const SizedBox(height: 8),
        const Text(
          'Verify all details match your official documents before submitting.',
          style: TextStyle(fontSize: 13, color: _C.textSecondary),
        ),
        const SizedBox(height: 20),

        _reviewSection('Personal Details', [
          _reviewRow('Full Name',
              '${_fNameCtrl.text} ${_mNameCtrl.text} ${_lNameCtrl.text}'.trim()),
          _reviewRow('Email',  _emailCtrl.text),
          _reviewRow('Phone',  _phoneCtrl.text),
          _reviewRow('DOB',    _selectedDob == null ? '—'
              : '${_selectedDob!.day}/${_selectedDob!.month}/${_selectedDob!.year}'),
          _reviewRow('Gender', _selectedGender ?? '—'),
          _reviewRow('Address',
              '${_addressCtrl.text}, ${_cityCtrl.text}, '
              '${_stateCtrl.text} ${_pincodeCtrl.text}'),
        ]),

        _reviewSection('Academic Details', [
          _reviewRow('PRN',            _prnCtrl.text),
          _reviewRow('Enrollment No',  _enrollmentCtrl.text),
          _reviewRow('Roll Number',    _rollCtrl.text),
          _reviewRow('Year of Study',  _yearOfStudyCtrl.text),
          _reviewRow('Batch',          _batchCtrl.text),
          _reviewRow('Admission Year', _admissionYearCtrl.text),
        ]),

        _reviewSection('Biometrics & Documents', [
          _reviewRow('Front Face', _faceFront != null ? '✅ Captured' : '❌ Missing'),
          _reviewRow('Left Face',  _faceLeft  != null ? '✅ Captured' : '— Skipped'),
          _reviewRow('Right Face', _faceRight != null ? '✅ Captured' : '— Skipped'),
          _reviewRow('Documents',  '${_uploadedDocs.length} uploaded'),
        ]),

        const SizedBox(height: 20),

        _checkRow(
          value   : _agreeTerms,
          onChanged: (v) => setState(() => _agreeTerms = v ?? false),
          label   : 'I agree to the Smart Campus Terms of Service.',
        ),
        const SizedBox(height: 8),
        _checkRow(
          value   : _agreePrivacy,
          onChanged: (v) => setState(() => _agreePrivacy = v ?? false),
          label   : 'I consent to the storage of biometric data per the privacy policy.',
        ),
        const SizedBox(height: 8),
      ],
    );
  }

  Widget _checkRow({
    required bool value,
    required void Function(bool?) onChanged,
    required String label,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Checkbox(
          value    : value,
          onChanged: onChanged,
          activeColor: _C.primary,
        ),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.only(top: 12),
            child  : Text(label,
                style: const TextStyle(fontSize: 13, color: _C.textPrimary)),
          ),
        ),
      ],
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Progress HUD
  // ─────────────────────────────────────────────────────────────────────────
  Widget _progressHud() {
    return Row(
      children: List.generate(_stepTitles.length, (i) {
        final active    = _currentStep == i;
        final completed = _currentStep > i;
        return Expanded(
          child: Column(children: [
            Container(
              width : 30, height: 30,
              decoration: BoxDecoration(
                color : completed ? _C.stepDone
                    : (active ? _C.stepActive : _C.stepInactive),
                shape : BoxShape.circle,
                border: Border.all(
                  color: active ? _C.stepActive : _C.border,
                  width: 2,
                ),
              ),
              alignment: Alignment.center,
              child: completed
                  ? const Icon(Icons.check, color: Colors.white, size: 16)
                  : Text(
                      '${i + 1}',
                      style: TextStyle(
                        color     : active ? Colors.white : _C.textSecondary,
                        fontWeight: FontWeight.bold,
                        fontSize  : 12,
                      ),
                    ),
            ),
            const SizedBox(height: 4),
            Text(
              _stepTitles[i],
              style: TextStyle(
                fontSize  : 9,
                fontWeight: active ? FontWeight.bold : FontWeight.normal,
                color     : active ? _C.stepActive : _C.textSecondary,
              ),
              maxLines : 1,
              overflow : TextOverflow.ellipsis,
              textAlign: TextAlign.center,
            ),
          ]),
        );
      }),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Bottom nav bar
  // ─────────────────────────────────────────────────────────────────────────
  Widget _navBar() {
    return Container(
      padding  : const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      decoration: BoxDecoration(
        color : _C.bgCard,
        border: Border(top: BorderSide(color: _C.border)),
      ),
      child: _isSubmitting || _isCheckingDuplicates
          ? const Center(child: CircularProgressIndicator())
          : Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                if (_currentStep > 0)
                  OutlinedButton.icon(
                    onPressed: _goBack,
                    icon : const Icon(Icons.arrow_back, size: 16),
                    label: const Text('Back'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: _C.primary,
                      side           : const BorderSide(color: _C.primary),
                    ),
                  )
                else
                  const SizedBox.shrink(),

                ElevatedButton.icon(
                  onPressed: _currentStep == 5 ? _submitRegistration : _goNext,
                  icon : Icon(
                    _currentStep == 5 ? Icons.send : Icons.arrow_forward,
                    size: 16,
                  ),
                  label: Text(_currentStep == 5 ? 'Submit' : 'Next'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _C.primary,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 28, vertical: 13),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8)),
                  ),
                ),
              ],
            ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Reusable widgets
  // ─────────────────────────────────────────────────────────────────────────

  Widget _sectionHeader(IconData icon, String title) => Padding(
        padding: const EdgeInsets.only(bottom: 4),
        child  : Row(children: [
          Icon(icon, color: _C.primary, size: 22),
          const SizedBox(width: 8),
          Text(title,
              style: const TextStyle(
                  fontSize  : 17,
                  fontWeight: FontWeight.w800,
                  color     : _C.textPrimary)),
        ]),
      );

  Widget _label(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 4),
        child  : Text(text,
            style: const TextStyle(
                fontSize  : 12,
                color     : _C.textSecondary,
                fontWeight: FontWeight.w500)),
      );

  InputDecoration _inputDec(String label, {Widget? suffix, String? error}) =>
      InputDecoration(
        labelText        : label,
        labelStyle       : const TextStyle(color: _C.textSecondary, fontSize: 14),
        floatingLabelStyle: const TextStyle(color: _C.primary, fontSize: 12),
        filled           : true,
        fillColor        : _C.bgField,
        errorText        : error,
        suffixIcon       : suffix,
        contentPadding   : const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        border           : OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide  : const BorderSide(color: _C.border)),
        enabledBorder    : OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide  : const BorderSide(color: _C.border)),
        focusedBorder    : OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide  : const BorderSide(color: _C.primary, width: 2)),
        errorBorder      : OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide  : const BorderSide(color: _C.danger)),
        focusedErrorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide  : const BorderSide(color: _C.danger, width: 2)),
        disabledBorder   : OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide  : const BorderSide(color: _C.border)),
      );

  /// Self-contained text field with explicit styling — never invisible
  Widget _tf(
    TextEditingController ctrl,
    String label, {
    bool      enabled     = true,
    bool      obscureText = false,
    int       maxLines    = 1,
    TextInputType keyboard = TextInputType.text,
    String?   errorText,
    Widget?   suffixIcon,
    String?   Function(String?)? validator,
    void      Function(String)?  onChanged,
  }) =>
      TextFormField(
        controller   : ctrl,
        enabled      : enabled,
        obscureText  : obscureText,
        maxLines     : maxLines,
        keyboardType : keyboard,
        onChanged    : onChanged,
        style        : const TextStyle(color: _C.textPrimary, fontSize: 14),
        decoration   : _inputDec(label, suffix: suffixIcon, error: errorText),
        validator    : validator,
      );

  /// Generic typed dropdown with visible styling
  Widget _dropdown<T>({
    required String   label,
    required T?       value,
    required List<T>  items,
    required void Function(T?) onChanged,
    String? Function(T?)? validator,
  }) =>
      DropdownButtonFormField<T>(
        value    : value,
        style    : const TextStyle(color: _C.textPrimary, fontSize: 14),
        decoration: _inputDec(label),
        items    : items
            .map((v) => DropdownMenuItem(
                  value: v,
                  child: Text(v.toString(),
                      style: const TextStyle(color: _C.textPrimary)),
                ))
            .toList(),
        onChanged: onChanged,
        validator: validator,
      );

  /// Async-safe dropdown — shows spinner / error / empty safely
  Widget _asyncDropdown({
    required AsyncValue<List<Map<String, dynamic>>> asyncValue,
    required String   label,
    required IconData icon,
    required String?  value,
    required void Function(String?) onChanged,
    String? Function(String?)? validator,
    String? filterKey,
    String? filterValue,
  }) {
    return asyncValue.when(
      loading: () => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 12, color: _C.textSecondary)),
          const SizedBox(height: 6),
          const LinearProgressIndicator(),
        ],
      ),
      error: (e, _) => TextFormField(
        enabled  : false,
        style    : const TextStyle(color: _C.textSecondary),
        decoration: _inputDec('$label (unavailable)',
            error: 'Could not load — check connection'),
      ),
      data: (items) {
        final filtered = (filterKey != null && filterValue != null)
            ? items.where((i) => i[filterKey] == filterValue).toList()
            : items;
        final safeValue =
            filtered.any((i) => i['id'] == value) ? value : null;
        return DropdownButtonFormField<String>(
          value    : safeValue,
          style    : const TextStyle(color: _C.textPrimary, fontSize: 14),
          decoration: _inputDec(label),
          hint     : Text(
            filtered.isEmpty ? 'No options available yet' : 'Select...',
            style: const TextStyle(color: _C.textSecondary),
          ),
          items: filtered
              .map((item) => DropdownMenuItem(
                    value: item['id'] as String?,
                    child: Text(item['name'] as String? ?? '',
                        style: const TextStyle(color: _C.textPrimary)),
                  ))
              .toList(),
          onChanged: onChanged,
          validator: validator,
        );
      },
    );
  }

  Widget _passwordStrengthBar() {
    final pwd = _passwordCtrl.text;
    if (pwd.isEmpty) return const SizedBox.shrink();
    int s = 0;
    if (pwd.length >= 8)                                    s++;
    if (pwd.contains(RegExp(r'[A-Z]')))                     s++;
    if (pwd.contains(RegExp(r'[a-z]')))                     s++;
    if (pwd.contains(RegExp(r'[0-9]')))                     s++;
    if (pwd.contains(RegExp(r'[!@#$%^&*(),.?":{}|<>]')))   s++;

    final Color  color;
    final String label;
    if (s >= 4)      { color = _C.success; label = 'Strong'; }
    else if (s >= 2) { color = _C.warning; label = 'Medium'; }
    else             { color = _C.danger;  label = 'Weak';   }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value          : s / 5,
            backgroundColor: _C.border,
            valueColor     : AlwaysStoppedAnimation(color),
            minHeight      : 6,
          ),
        ),
        const SizedBox(height: 4),
        Text(label,
            style: TextStyle(color: color, fontSize: 11,
                fontWeight: FontWeight.bold)),
      ],
    );
  }

  Widget _reviewSection(String title, List<Widget> rows) => Container(
        margin    : const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          color       : _C.bgCard,
          borderRadius: BorderRadius.circular(12),
          border      : Border.all(color: _C.border),
        ),
        child: ExpansionTile(
          initiallyExpanded         : true,
          title                     : Text(title,
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold,
                  color: _C.textPrimary)),
          childrenPadding           : const EdgeInsets.fromLTRB(16, 0, 16, 16),
          expandedCrossAxisAlignment: CrossAxisAlignment.start,
          children                  : rows,
        ),
      );

  Widget _reviewRow(String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child  : Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SizedBox(
            width: 130,
            child: Text(label,
                style: const TextStyle(fontWeight: FontWeight.w600,
                    fontSize: 13, color: _C.textSecondary)),
          ),
          Expanded(
            child: Text(value,
                style: const TextStyle(fontSize: 13, color: _C.textPrimary)),
          ),
        ]),
      );

  String? Function(String?) _req(String field) =>
      (v) => (v == null || v.trim().isEmpty) ? '$field is required' : null;
}