from rest_framework import viewsets
from .models import StudentProfile, StudentSubjectEnrollment
from .serializers import StudentProfileSerializer, StudentSubjectEnrollmentSerializer
from rest_framework.permissions import IsAuthenticated

class StudentProfileViewSet(viewsets.ModelViewSet):
    queryset = StudentProfile.objects.all()
    serializer_class = StudentProfileSerializer
    permission_classes = [IsAuthenticated]

class StudentSubjectEnrollmentViewSet(viewsets.ModelViewSet):
    queryset = StudentSubjectEnrollment.objects.all()
    serializer_class = StudentSubjectEnrollmentSerializer
    permission_classes = [IsAuthenticated]
