"""
Real Haversine geofencing utilities.
No mocking. No hardcoded values.
All calculations use real spherical earth geometry.
"""
import math


def haversine_distance(lat1: float, lng1: float,
                       lat2: float, lng2: float) -> float:
    """
    Calculate the great-circle distance between two GPS points.
    Returns distance in METERS.
    Uses the Haversine formula (accurate for short distances).
    """
    R = 6_371_000.0  # Earth radius in meters

    phi1     = math.radians(float(lat1))
    phi2     = math.radians(float(lat2))
    delta_phi    = math.radians(float(lat2) - float(lat1))
    delta_lambda = math.radians(float(lng2) - float(lng1))

    a = (math.sin(delta_phi / 2) ** 2
         + math.cos(phi1) * math.cos(phi2)
         * math.sin(delta_lambda / 2) ** 2)

    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

    return R * c


def check_inside_room(lat: float, lng: float,
                      altitude: float, room) -> dict:
    """
    Check if a GPS point is inside a VirtualRoom boundary.

    Args:
        lat, lng   : Student's current GPS coordinates
        altitude   : Student's altitude in meters
        room       : VirtualRoom model instance

    Returns:
        {
          'inside'              : bool,  # True only if BOTH 2D and altitude pass
          'inside_2d'           : bool,  # inside horizontal circle
          'altitude_ok'         : bool,  # inside altitude range
          'distance_from_center': float, # meters from room center
          'distance_to_boundary': float, # meters outside boundary (0 if inside)
        }
    """
    distance = haversine_distance(
        lat, lng,
        float(room.center_lat),
        float(room.center_lng),
    )

    inside_2d    = distance <= float(room.radius_meters)
    altitude_ok  = (float(room.min_altitude)
                    <= float(altitude)
                    <= float(room.max_altitude))

    return {
        'inside'              : inside_2d and altitude_ok,
        'inside_2d'           : inside_2d,
        'altitude_ok'         : altitude_ok,
        'distance_from_center': round(distance, 2),
        'distance_to_boundary': round(
            max(0.0, distance - float(room.radius_meters)), 2
        ),
    }


def detect_gps_spoofing(lat: float, lng: float,
                        prev_lat, prev_lng,
                        elapsed_seconds: float) -> dict:
    """
    Basic GPS spoofing detection based on physically impossible speed.
    Returns {'spoofed': bool, 'reason': str}
    """
    if prev_lat is None or prev_lng is None:
        return {'spoofed': False, 'reason': 'First location record'}

    distance = haversine_distance(lat, lng, prev_lat, prev_lng)
    elapsed  = max(float(elapsed_seconds), 1.0)
    speed    = distance / elapsed  # meters per second

    # > 55 m/s = > 200 km/h — impossible on foot
    if speed > 55.0:
        return {
            'spoofed': True,
            'reason' : (
                f'Unrealistic movement speed: {speed:.1f} m/s '
                f'({speed * 3.6:.1f} km/h)'
            ),
        }

    return {'spoofed': False, 'reason': 'Normal movement speed'}
